# About

The principles fedtail grows from, who wrote it and under which licence.

## Principles

<!-- include: parts/principles -->
1. **Nothing jumps.** Open a lane and you stand at the first unread. New posts come and your
   place doesn't move, only the counter grows. You read in order, like RSS.
2. **Every reply knows what it answers.** Over a reply, a strip with the start of the original
   post; under someone's comment, what you said back to it: come back to a thread a week later
   and you see at once where you were. A click opens the whole thread as a tree.
3. **Lanes are apart.** People apart, bots apart, replies to me apart from other mentions.
4. **Private by default.** A new post goes to followers only. A reply is never more public than
   the original.
5. **Every behaviour is a config key.** The settings window is a face of the same
   `config.toml`: it shows its keys and writes back into it. The defaults are as the author
   likes them; "like everyone else" is a flag away. New features come switchable.
6. **Other servers get no token of yours.** Whatever fedtail takes straight from the author's
   server over ActivityPub goes anonymously: they see only your IP.
7. **One core, many faces.** The Qt window, the GTK window, the terminal, the browser and the
   phone show the same things and behave the same: the core decides, the interfaces only
   draw.
8. **One profile, one account.** A second account is a second profile (`--profile`); if you
   like, all accounts come together in one window (`accounts.merge`).
9. **Grown-ups sort things out themselves.** Arts mode (after @arts, the founder of Point.im):
   everything as the author posted it, no nannying. Anyone can be told where to go, an admin
   too — and the admin can say the same back.
<!-- /include -->

## Only in fedtail

What none of the thirteen clients we compared with has ([the whole matrix](ref/comparison.md)):

<!-- include: parts/only-in-fedtail -->
- **Lanes:** Bots in a lane of their own · Who is in a list leaves the general lanes · Into a list — the author or the booster; only people you follow · Into a list right after a follow · A tag as its author writes it, as on Point · An empty live lane says why it's empty · Filtering a lane by media and boosts · Repeated boosts don't bring an old post up again · Find in a lane · Sending to a slow server without doubles · Find in every lane at once · Free lanes: a lane you assemble yourself · Federated and tags wider than your server · The lane editor · “Unsorted”: no post gets lost · Sets of lanes “as in other clients” · “To me”: replies and mentions in one lane · Home's quick filters: tags, boosts, threads with news · Home without other people's conversations · Important people · Lanes of rules: order by counts, “what did I miss”, “Why is it here?” · A library of pictures for your own lanes
- **Threads:** A reply comes into a lane with what it answers · A whole thread: replies from the author's server · Thread subscriptions, as on Point · A thread with new replies shows on its card · Where a thread opens: at the post or at the first new comment · Following the replies to all of someone's posts
- **Read marks and place:** Oldest on top, nothing jumps · Catching up with no holes · When a post counts as read · Read marks, thread subscriptions and lane order shared by all your devices · Only the cards near the screen are in memory · Esc draws a curtain instead of closing the window · A draft's pictures travel with it · News behind the filters still counts · Sync set up in the window step by step, a new device by a password alone · Sync through a folder on the phone — by picking the folder · "A device joined" in Activity — on it and on the others
- **The post card:** Arts mode · Fact-check a post · Honest counters · The post under the mouse lit · The numbers under the posts on screen kept fresh · A post's character count
- **Pictures and video:** Video without a hardware decoder (the default) · Search the web for a picture · Pictures and video ahead of time, a disk cache · Files attached, text ones read inside
- **Profiles:** Posts older than my server knows · “Following since …”
- **Writing:** Visibility: private by default, a reply never wider than the post · A file the server won't take — said at once · CamelCase hint for hashtags · Call someone into a thread · Reply with quotes, piece by piece · A command line as on Point · Short post names the same on every device · A comment is #post/N, as on Point
- **Notifications and activity:** Desktop notifications with privacy levels · Approve a reply, like, boost (GoToSocial) · Direct messages read here are read on the server too · Activity's quick filters · Who stopped following you · Activity says whom you followed · Someone new in a private talk — shown at once · Slow mode and “notify at most every…” · “Of them new”: what the last update brought
- **The application:** A theme as one file: take it out, change it, bring it in · `fedtail --check`: what the system lacks — and one apt line · A hung copy doesn't stop a start
<!-- /include -->

## Who wrote it

The code, from the first line to the icon, is written by Claude (Anthropic), an AI. The idea,
testing every build on his own node and every remark are a human's. The version, the build and
the links — ≡ → "About".

## Licence

GPL-3.0-or-later. The opossum on the icon (and the swinging one, while the lanes update) isn't
under the GPL: it is a sticker from an official [Telegram](https://telegram.org) sticker pack
([fluffyloafer](https://t.me/addstickers/fluffyloafer)). Drawn by [Boggart Owl](https://www.instagram.com/boggartowl/) — thank you; thanks also to Telegram and Pavel Durov for stickers anyone may share.

"""In-app links, `fedtail:<action>/<arg>`, and what each one does.

Cards, profiles and menus speak in these links (richtext.link, the post menu in
common/actions.py); a window hands every link it gets to `Links.open()`. Opening a
place (a thread, a profile, a tag) and anything that needs a dialog stays the window's
job — it is asked through the `host` it passes in; what happens on the core, and in
which order, is decided here, once for every toolkit.

The host is the window. It must have:
  call(future, ok=None, fail=None)   run ok/fail in the GUI thread (the bridge)
  status(text)                       a passing message (the status line)
  error(text)                        a failure to show
  confirm(title, text, then)         ask; then() only on yes (may answer later: GTK)
  open_url(url) open_thread(id, at) open_account(id) open_tag(tag) resolve_link(url)
  copy_handle(handle) put_alias(alias)
  compose(reply_to=None, invite=False, edit=None, quote=None)
  show_history(post) report(post) open_reactions(post, kind) open_quotes(post)
  read_up_to(id) redrafted(redraft)
  play_link(media)                   optional: a link to a video or sound file, in the
                                     interface's own player (media.links_in_player)
A host without one of the optional ones (report, open_quotes…) gets a "not here yet"
status instead — the GTK window grows into it stage by stage.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from urllib.parse import quote, unquote

from ...i18n import _
from ...model.text import snippet
from . import timed

log = logging.getLogger(__name__)

PREFIX = "fedtail:"
# actions whose argument is not a post id
NOT_A_POST = ("account", "tag", "resolve", "alias", "copyhandle", "eventyes", "eventno",
              "eventhide")


@dataclass(frozen=True)
class Link:
    action: str
    arg: str


def parse(url):
    """A fedtail: link as (action, argument), or None for a link to the outside."""
    if not url or not url.startswith(PREFIX):
        return None
    action, _sep, arg = url[len(PREFIX):].partition("/")
    return Link(action, arg)


def make(action, arg):
    return f"{PREFIX}{action}/{arg}"


# where a thread opens (threads.open_at, a lane's open_at): the link says it —
# fedtail:thread/<id> at that post, fedtail:threadnew/<id> at its first unread comment
THREAD_AT = {"post": "thread", "first_unread": "threadnew"}


def thread_url(pid, at="post"):
    """The link opening the thread of post `pid`, standing where `at` says."""
    return make(THREAD_AT.get(at, "thread"), pid)


def tag_menu(url, view=None):
    """A post's tag (fedtail:tag/…), right-clicked — or clicked, feed.tag_click = "menu":
    [(words, link)] — the tag as the post's author writes it (when the link names them),
    the tag everywhere; with the view: followed or not, into the lanes, muted or shown
    again (each as it stands now — Mastodon's own menu of a tag, 08.11); without, muted
    in one click. [] for any other link."""
    link = parse(url)
    if link is None or link.action != "tag":
        return []
    name, _s, by = unquote(link.arg).partition(" by:")
    q = quote(name, safe="")
    out = []
    if by:
        out.append((_("tag_by_author", tag=name), make("tagby", quote(f"{name} by:{by}",
                                                                   safe=""))))
    out.append((_("tag_everywhere_n", tag=name), make("tagall", q)))
    followed = getattr(view, "tag_followed", None)
    followed = followed(name) if callable(followed) else None
    if followed is not None:  # known (whom and what I follow is kept): its state
        out.append((_("tag_unfollow_n" if followed else "tag_follow_n", tag=name),
                    make("unfollowtag" if followed else "followtag", q)))
    if view is not None:
        out.append((_("tag_to_lanes_n", tag=name), make("place", quote(f"taglanes {name}",
                                                                     safe=""))))
    muted = getattr(view, "tag_muted", None)
    muted = bool(muted(name)) if callable(muted) else False
    out.append((_("tag_unmute_n" if muted else "tag_mute_n", tag=name),
                make("unmutetag" if muted else "mutetag", q)))
    return out


# a link in a post's text to a file of these, played in the interface's own player
VIDEO_LINK_EXT = (".mp4", ".webm", ".mov", ".m4v", ".mkv", ".ogv")
AUDIO_LINK_EXT = (".mp3", ".ogg", ".oga", ".opus", ".m4a", ".flac", ".wav")


def media_link(url):
    """"video" / "audio" for an http(s) link to such a file (by its path's ending), or
    "" — a server that didn't take an attachment leaves its link in the text
    ("…0ba3a335ab822c8c.mp4 (error: file size limit reached)", 30.10)."""
    from urllib.parse import urlsplit
    if not isinstance(url, str) or not url.lower().startswith(("https://", "http://")):
        return ""
    path = urlsplit(url).path.lower()
    if path.endswith(VIDEO_LINK_EXT):
        return "video"
    if path.endswith(AUDIO_LINK_EXT):
        return "audio"
    return ""


class Links:
    def __init__(self, view, host):
        self.view, self.host = view, host

    def open(self, url):
        link = parse(url)
        if link is None:
            kind = media_link(url)
            play = getattr(self.host, "play_link", None)
            if kind and play is not None and \
                    self.view.cfg["ui"].get("links_in_player", True):
                from ...model import Media, Ref
                log.info("link: the player (%s)", kind)
                play(Media(ref=Ref("link", "", url), kind=kind, url=url))
                return
            log.info("link: browser")
            self.host.open_url(url)
            return
        action, arg = link.action, link.arg
        log.info("action %s %s", action, arg if action not in ("tag", "resolve") else "…")
        h = self.host
        if action == "copyhandle":  # someone's @user@server, to call them anywhere
            self._ask(h, "copy_handle", unquote(arg))
        elif action == "alias":  # a post's #abc: its thread, or into the command line
            from .actions import code_to_line
            post = None if code_to_line(self.view.cfg) else self.view.by_alias(arg)
            if post is not None:  # (the hand reaches for it to open the post, 08.11)
                h.open_thread(post.id, "post")
            else:
                self._ask(h, "put_alias", arg)
        elif action == "tag":  # a post's tag: its menu, as its author writes it, everywhere
            name, _s, by = unquote(arg).partition(" by:")
            how = self.view.cfg["feed"].get("tag_click", "menu")
            if how == "menu":
                self._tag_menu(h, url, name)
            elif by and how == "author":
                self._ask(h, "open_tag", f"{name} by:{by}")
            else:
                self._ask(h, "open_tag", name)
        elif action == "tagall":  # the tag's menu: everywhere, whatever tag_click says
            self._ask(h, "open_tag", unquote(arg).partition(" by:")[0])
        elif action == "tagby":  # …and as the post's author writes it
            self._ask(h, "open_tag", unquote(arg))
        elif action in ("followtag", "unfollowtag"):  # from the tag's menu
            tag, on = unquote(arg).lstrip("#"), action == "followtag"
            h.call(self.view.follow_tag(tag, on), fail=h.error,
                   ok=lambda _r: h.status(_("tag_followed_msg" if on else
                                            "tag_unfollowed_msg", tag=tag)))
        elif action in ("mutetag", "unmutetag"):  # a hashtag, in one click (Fedilab's way)
            tag, on = unquote(arg).lstrip("#"), action == "mutetag"
            h.call(self.view.mute_tag(tag, on), fail=h.error,
                   ok=lambda _r: h.status(_("tag_muted_msg" if on else "tag_unmuted_msg",
                                            tag=tag)))
        elif action == "resolve":
            self._ask(h, "resolve_link", unquote(arg))
        elif action in ("thread", "threadnew"):
            h.open_thread(arg, "first_unread" if action == "threadnew" else "post")
        elif action == "account":
            self._ask(h, "open_account", arg)
        elif action == "place":  # one of fedtail's own pages (a device's row: ≡ → Sync)
            name, _s, parg = unquote(arg).partition(" ")  # "<place> <its arg>"
            self._ask(h, "open_place", *((name, parg) if parg else (name,)))
        elif action in ("eventyes", "eventno"):  # a follow request, an approval: answered
            ok = action == "eventyes"
            h.call(self.view.answer_event(unquote(arg), ok),
                   ok=lambda found: h.status(_(("approved" if ok else "rejected") if found
                                               else "approval_gone")),
                   fail=h.error)
        elif action == "eventhide":  # × on an event's row: its events, gone
            h.call(self.view.dismiss_events([unquote(i) for i in arg.split(",") if i]),
                   fail=h.error)
        else:
            post = self.view.by_id(arg)
            if post is None:
                h.error(_("not_in_cache"))
            else:
                self.post_action(action, arg, post)

    def _tag_menu(self, h, url, name):
        """feed.tag_click = "menu": the tag's menu (tag_menu) — by the pointer where the
        window has one (tag_menu_here → True), else as a choice of its items."""
        items = tag_menu(url, self.view)
        here = getattr(h, "tag_menu_here", None)
        if here is not None and here(items):
            return
        h.choose("#" + name, "", [(link, words) for words, link in items],
                 lambda key, _ticked: self.open(key))

    @staticmethod
    def _ask(host, name, *args):
        fn = getattr(host, name, None)
        if fn is None:
            host.status(_("gtk_not_yet"))
            return None
        return fn(*args)

    def post_action(self, action, arg, st):
        """The actions on a post (st: the Post)."""
        v, h = self.view, self.host
        if action == "poll":
            h.call(v.refresh_poll(st), fail=h.error)
        elif action == "reply":
            h.compose(reply_to=st)
        elif action == "invite":  # call someone into this thread: a reply naming them
            if v.me:
                h.compose(reply_to=st, invite=True)
        elif action == "edit":
            h.compose(edit=st)
        elif action == "history":
            self._ask(h, "show_history", st)
        elif action == "mute":  # how long, and their notifications too or not
            timed.mute(v, h, st.author)
        elif action == "block":
            acc = st.author
            h.confirm(_("block"), _("block_q", acct=acc.handle),
                      lambda: h.call(v.block(acc.id, True),
                                     ok=lambda _r: h.status(_("blocked_msg",
                                                              acct=acc.handle))))
        elif action == "hidepost":  # this one post, through a filter of the server's
            h.confirm(_("hide_post"), _("hide_post_tip"),
                      lambda: h.call(v.hide_post(st), ok=lambda _r: h.status(_("post_hidden")),
                                     fail=h.error))
        elif action == "bookmark":
            on = not st.mine.bookmarked
            h.call(v.bookmark(st, on),
                   ok=lambda _s: h.status(_("bookmarked" if on else "unbookmarked")))
        elif action == "fav":
            h.call(v.like(st))
        elif action == "boost":
            h.call(v.share(st))
        elif action == "open":
            h.open_url(st.url or st.uri)
        elif action in ("sub", "unsub"):
            sub = action == "sub"
            h.call((v.subscribe if sub else v.unsubscribe)(st),
                   ok=lambda _r: h.status(_("subbed" if sub else "unsubbed")))
        elif action == "report":
            self._ask(h, "report", st)
        elif action == "blockdomain":
            domain = st.author.handle.partition("@")[2]
            if domain:
                h.confirm(_("block_domain", domain=domain), _("block_domain_q", domain=domain),
                          lambda: h.call(v.block_domain(domain, True),
                                         ok=lambda _d: h.status(_("domain_blocked",
                                                                  domain=domain)),
                                         fail=h.error))
        elif action == "quote":
            h.compose(quote=st)
        elif action == "readone":
            v.mark_read([arg])
        elif action == "readupto":
            self._ask(h, "read_up_to", arg)
        elif action in ("favourited_by", "reblogged_by"):
            self._ask(h, "open_reactions", st, action)
        elif action in ("mutethread", "unmutethread"):
            on = action == "mutethread"
            h.call(v.mute_thread(st, on),
                   ok=lambda _s: h.status(_("thread_muted" if on else "thread_unmuted")),
                   fail=h.error)
        elif action == "quotes":
            self._ask(h, "open_quotes", st)
        elif action == "react":  # an emoji of mine on it: the place of reactions
            self._ask(h, "_place", "react", st.id)
        elif action == "why":  # which lanes take it, by which condition (feeds.md §8)
            self._ask(h, "_place", "why", arg or st.id)
        elif action == "raw":  # the post's JSON as the server gave it (debug.raw_json)
            self._ask(h, "_place", "raw", st.id)
        elif action == "around":  # what came just before and after it (feed.around_post)
            self._ask(h, "_place", "around", st.id)
        elif action == "linkposts":  # who else shared the post's link (Mastodon 4.3)
            if st.card and st.card.url:
                self._ask(h, "open_link_posts", st.card.url)
        elif action == "revokequote":
            mine = st.quote.post if st.quote else None
            if mine:
                h.confirm(_("revoke_quote"), _("revoke_quote_q", acct=st.author.handle),
                          lambda: h.call(v.revoke_quote(mine, st),
                                         ok=lambda _s: h.status(_("quote_taken_back")),
                                         fail=h.error))
        elif action in ("pin", "unpin"):
            on = action == "pin"
            h.call(v.pin(st, on), ok=lambda _s: h.status(_("pinned_msg" if on
                                                           else "unpinned_msg")),
                   fail=h.error)
        elif action == "delete":
            h.confirm(_("delete_q_title"), _("delete_q", text=snippet(st, 200)),
                      lambda: h.call(v.delete(st)))
        elif action == "redraft":
            n = len(st.media)
            q = _("redraft_q", text=snippet(st, 200)) + (
                "\n\n" + _("redraft_media", n=n) if n else "")
            h.confirm(_("redraft"), q,
                      lambda: h.call(v.redraft(st), ok=h.redrafted, fail=h.error))
        else:
            log.warning("unknown action %s", action)

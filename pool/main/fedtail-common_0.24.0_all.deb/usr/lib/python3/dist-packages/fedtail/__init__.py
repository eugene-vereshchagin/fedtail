"""fedtail — desktop fediverse client. See docs/en/dev/design.md."""

__version__ = "0.24.0"

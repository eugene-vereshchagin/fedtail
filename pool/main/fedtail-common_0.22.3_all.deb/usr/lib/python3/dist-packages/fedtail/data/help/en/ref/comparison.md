# fedtail and other clients

The features of the [full list](/docs/en/features.md), as one matrix a chapter: whether other clients have the same. ✓ — they do, empty — they don't or it's unknown. From their READMEs and release notes (autumn 2026) and general knowledge, without trying each one live; the details and remarks are in the “Others” column of the full list.

fedtail: ✓ — has, ◐ — partly, — — no, ⏳ — planned.

## Lanes

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Federated, Home, Local | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Bots in a lane of their own | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Personal lanes | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Lists as lanes | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   | ✓ |   |   |   |
| Whose replies a list shows | ✓ | ✓ |   | ✓ | ✓ | ✓ |   | ✓ |   |   |   |   |   |   |
| Who is in a list leaves the general lanes | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Who is in a list; your own order of lists | ✓ | ✓ |   | ✓ |   |   |   |   |   |   |   |   |   |   |
| Into a list — the author or the booster; only people you follow | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Into a list right after a follow | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Hashtag lane, following tags | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| A tag as its author writes it, as on Point | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| My likes | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   | ✓ | ✓ |   |   |
| Bookmarks | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Trends | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   | ✓ |   |   |   |   |   |   |
| An empty live lane says why it's empty | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Filtering a lane by media and boosts | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Repeated boosts don't bring an old post up again | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| All / Posts only / New; Feed / Conversations | ✓ |   |   |   | ✓ |   |   |   |   |   |   |   |   |   |
| Find in a lane | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Sending to a slow server without doubles | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Find in every lane at once | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Finding people, tags and posts | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| A lane of several tags | ✓ |   |   |   | ✓ |   |   | ✓ |   |   |   | ✓ |   |   |
| Columns side by side | ✓ | ✓ |   |   | ✓ |   |   |   |   | ✓ |   | ✓ |   | ✓ |
| Collections of people (Mastodon 4.6) | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |   |   |   |   |
| Another server's public timeline | ✓ |   |   |   |   |   |   | ✓ |   |   |   |   |   |   |
| A link's timeline (Mastodon 4.3+) | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Free lanes: a lane you assemble yourself | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Federated and tags wider than your server | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| The lane editor | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| “Unsorted”: no post gets lost | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Only the languages you read | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Sets of lanes “as in other clients” | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| “To me”: replies and mentions in one lane | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Home's quick filters: tags, boosts, threads with news | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Important people | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Lanes of rules: order by counts, “what did I miss”, “Why is it here?” | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Lanes from someone's wall, a search and RSS | ✓ |   |   |   | ✓ |   |   |   |   |   |   |   |   |   |
| Rules: for a while, by name, at most N per author, by author, "Not in Home" | ✓ |   |   | ✓ | ✓ |   |   |   | ✓ |   |   |   |   |   |
| A library of pictures for your own lanes | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |

## Threads

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A thread as a tree, comments numbered | ✓ |   |   |   | ✓ |   |   |   |   |   |   |   |   |   |
| Over a reply — what it answers | ✓ |   |   |   |   |   |   |   |   | ✓ | ✓ |   |   |   |
| A whole thread: replies from the author's server | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| A thread grows when Mastodon has gathered the replies | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Thread subscriptions, as on Point | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Mute a thread | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |
| A thread with new replies shows on its card | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Threads: where replies come from, growing by itself, only the followed, by branch, "Around this post" | ✓ |   |   | ✓ |   |   |   |   | ✓ |   |   |   | ✓ |   |
| Where a thread opens: at the post or at the first new comment | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Following the replies to all of someone's posts | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |

## Read marks and place

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Oldest on top, nothing jumps | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Catching up with no holes | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| When a post counts as read | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| The reading place is shared with other clients | ✓ | ✓ | ✓ | ✓ | ✓ |   |   | ✓ |   |   |   |   |   |   |
| Read marks, thread subscriptions and lane order shared by all your devices | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Only the cards near the screen are in memory | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Esc draws a curtain instead of closing the window | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| A draft's pictures travel with it | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| New posts wait for Refresh | ✓ |   |   |   |   | ✓ |   |   |   |   |   |   |   |   |
| Sync set up in the window step by step, a new device by a password alone | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| "A device joined" in Activity — on it and on the others | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| A lane without a seam: older posts come by themselves | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |   |

## The post card

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Arts mode | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Content warnings (CW) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Open every CW in a thread at once | ✓ |   |   |   |   |   |   |   |   | ✓ | ✓ |   |   |   |
| Sensitive pictures | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Link cards | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Servers' emoji as pictures | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| No emoji at all | ✓ |   | ✓ |   |   |   |   |   | ✓ |   |   |   |   |   |
| Quotes: showing them | ✓ | ✓ |   | ✓ | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |
| Polls: seeing and voting | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Poll results without voting | ✓ |   |   |   |   |   |   |   | ✓ |   |   |   |   |   |
| Edit history | ✓ | ✓ |   | ✓ | ✓ | ✓ |   |   |   |   |   | ✓ |   |   |
| Translation by the server | ✓ | ✓ |   | ✓ | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |
| Emoji reactions | ✓ |   |   |   | ✓ | ✓ |   |   | ✓ |   |   |   |   |   |
| Who liked and boosted | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   | ✓ |   |   |
| Honest counters | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| The post under the mouse lit | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| The numbers under the posts on screen kept fresh | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Who quoted my post | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Folding hashtag padding | ✓ |   |   |   | ✓ |   |   |   |   |   |   |   |   |   |
| Labels on the card | ✓ |   |   |   |   |   |   |   |   | ✓ |   |   |   |   |
| Sending emoji reactions | ✓ |   |   |   | ✓ | ✓ |   |   | ✓ |   |   |   |   |   |

## Pictures and video

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Picture viewer | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Picture grid | ✓ | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |   |   |   |
| Picture descriptions (alt) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Video, audio, gifs inside the window | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Video without a hardware decoder (the default) | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Save a picture, video, gif | ✓ |   | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |
| Pictures and video ahead of time, a disk cache | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |

## Profiles

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Your own and other people's profiles | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| In a profile: posts, posts and replies, media | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |
| Who else shared a link | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Pinned posts | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Featured tags and recommended people | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| A little-known person's profile — from their server | ✓ |   |   |   |   |   |   |   |   |   | ✓ |   |   |   |
| Posts older than my server knows | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Followers and follows from the person's server | ✓ |   |   |   |   |   |   |   |   |   | ✓ |   |   |   |
| “Following since …” | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| The person has moved | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |

## Writing

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| A video's cover; picture descriptions in a post's edit | ✓ | ✓ |   | ✓ |   | ✓ |   |   |   |   |   |   |   |   |
| The compose panel and drafts | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Visibility: private by default, a reply never wider than the post | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Preview before sending | ✓ |   |   |   |   |   |   |   | ✓ |   |   |   |   |   |
| Formatting buttons | ✓ |   |   |   | ✓ |   |   |   | ✓ |   |   |   |   |   |
| Content warning (CW) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Pictures: drag, paste, description, focus | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Shrinking pictures to the server's limit | ✓ |   |   |   |   |   |   |   | ✓ |   |   |   |   |   |
| Completing #tags, @nicks, :emoji: | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| CamelCase hint for hashtags | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| The post's language | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| A poll in a post | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Call someone into a thread | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Reply with quotes, piece by piece | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Copy the handle @user@server | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Quoting a post; who may quote mine | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| A scheduled post | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   | ✓ |   |   |   |
| Edit, delete, pin your own post | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Delete and redraft | ✓ | ✓ |   |   |   |   |   |   |   |   | ✓ |   |   |   |
| A thread as a chain | ✓ |   |   |   |   |   |   | ✓ |   |   |   |   |   |   |
| A command line as on Point | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Short post names the same on every device | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| A comment is #post/N, as on Point | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Spell checking in the compose panel | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |   | ✓ |   |
| Language check, link → quote, sending in the background, scheduled → editor, Drafts | ✓ |   |   |   |   |   |   |   | ✓ |   |   |   | ✓ |   |

## People and order

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Follows and follow requests | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Hide a person's boosts; the languages of a follow | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   | ✓ |   |   |
| Mute, block, word filters | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Mute a hashtag in one click | ✓ |   |   |   |   |   |   |   | ✓ |   |   |   |   |   |
| Mute for a while; posts only | ✓ | ✓ |   | ✓ |   |   |   |   | ✓ |   |   |   |   |   |
| Hide a single post | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Editing a filter | ✓ | ✓ |   | ✓ |   |   |   |   | ✓ |   |   |   |   |   |
| Report: which rules it breaks | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |
| Block a whole server | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Report to the moderators | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| A private note on a person | ✓ | ✓ |   | ✓ |   |   |   | ✓ |   |   |   |   |   |   |
| A bell on a person's posts | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   | ✓ |   |   |   |
| Remove from followers without a block | ✓ | ✓ |   | ✓ |   |   |   |   |   |   |   |   |   |   |
| Recommend people and tags on your own profile | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| The server's suggestions, the profile directory | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |
| About the server | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Your profile | ✓ | ✓ |   | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |
| Profile: hide follows, posts found by search, article authorship, tag suggestions | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| About the server: terms, whom it cut off, its translator | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Post visibility as set on the server | ✓ | ✓ |   | ✓ |   |   |   |   |   |   |   |   |   |   |
| Your own names and colours for people, why a post is in Home, a post's JSON | ✓ |   |   |   | ✓ |   | ✓ |   | ✓ |   |   |   | ✓ |   |

## Notifications and activity

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Desktop notifications with privacy levels | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Activity: likes, boosts, follows | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Grouping notifications | ✓ | ✓ |   | ✓ | ✓ |   |   | ✓ |   |   |   |   |   |   |
| Approve a reply, like, boost (GoToSocial) | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Notifications from strangers apart | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Severed relationships and moderators' warnings | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |
| Dismiss a notification, clear them all | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Server announcements | ✓ | ✓ |   |   | ✓ | ✓ |   |   |   |   | ✓ |   |   |   |
| The unread number on the icon | ✓ |   |   |   |   |   | ✓ |   |   |   |   |   |   |   |
| Direct messages read here are read on the server too | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Activity's quick filters | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Who stopped following you | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Activity says whom you followed | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Someone new in a private talk — shown at once | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Push notifications (Web Push, UnifiedPush) | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |
| The server's grouped notifications (v2) | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |   |   |   |   |
| Slow mode and “notify at most every…” | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| “Of them new”: what the last update brought | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| Follow requests in any lane | ✓ | ✓ |   | ✓ | ✓ |   |   |   |   |   |   |   |   |   |

## Several accounts

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Profiles and the switcher | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Log in again, log out | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| All accounts in one window | ✓ |   |   | ✓ | ✓ | ✓ | ✓ |   |   | ✓ |   |   |   | ✓ |
| An account's colour in the shared window | ✓ |   |   |   |   |   |   |   | ✓ |   |   |   |   |   |
| Acting as another account | ✓ |   |   |   |   |   | ✓ |   |   | ✓ |   |   |   |   |

## The application

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Themes as files | ✓ |   |   |   |   |   |   | ✓ |   |   | ✓ |   |   |   |
| Trying a theme without a restart | ✓ |   |   |   | ✓ | ✓ |   | ✓ |   |   |   |   |   |   |
| The config as a file in chapters | ✓ |   |   |   |   |   |   |   |   |   |   | ✓ |   |   |
| The settings reference | ✓ |   |   |   |   |   |   |   |   |   |   | ✓ |   |   |
| Window, tray, keys | ✓ | ✓ |   | ✓ | ✓ | ✓ |   |   |   |   |   | ✓ |   |   |
| Links to posts and profiles — inside | ✓ |   |   | ✓ | ✓ | ✓ |   |   | ✓ |   | ✓ |   |   |   |
| Open a link in the running fedtail | ✓ |   |   |   |   |   |   |   |   |   | ✓ |   |   |   |
| Everything is stored locally, readable offline | ✓ |   | ✓ |   |   |   |   | ✓ |   |   |   |   |   |   |
| Polling the server and the live stream | ✓ | ✓ |   |   | ✓ | ✓ | ✓ | ✓ |   |   |   |   |   | ✓ |
| Screen readers | ◐ | ✓ | ✓ | ✓ |   |   |   |   |   |   |   |   |   |   |
| Interface language | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| A proxy, Ctrl+1…9, pinned tabs, the stream on Wi-Fi only, statistics, LibreTranslate and translating by itself | ✓ |   |   | ✓ |   |   | ✓ |   | ✓ |   |   |   |   |   |
| `fedtail --check`: what the system lacks — and one apt line | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |
| A hung copy doesn't stop a start | ✓ |   |   |   |   |   |   |   |   |   |   |   |   |   |

## Interfaces

| What | fedtail | Mastodon web | Tusky | Ivory | Phanpy | Elk | Tokodon | Ice Cubes | Fedilab | Sengi | Megalodon | tut | Tuba | Whalebird |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Commands in a terminal | ✓ |   |   |   |   |   |   |   |   |   |   | ✓ |   |   |
| Android: a phone and a tablet | ◐ |   | ✓ |   |   |   |   |   | ✓ |   |   |   |   |   |
| A terminal interface (Textual) | ✓ |   |   |   |   |   |   |   |   |   |   | ✓ |   |   |
| Web on localhost | ✓ |   |   |   | ✓ | ✓ |   |   |   |   |   |   |   |   |
| GTK4 + libadwaita | ✓ |   |   |   |   |   |   |   |   |   |   |   | ✓ |   |

Only in fedtail — **61** features of the 189 compared.

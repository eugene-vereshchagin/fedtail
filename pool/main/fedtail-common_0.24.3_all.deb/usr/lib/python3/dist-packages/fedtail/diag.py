"""Diagnostics: logs, crash traces, stack dumps, resource stats, bug reports.

fedtail is meant to stay open for days. When it falls over, hangs or grows fat,
the files here are what you send for a diagnosis. Until 1.0 everything is on by
default and verbose (`[debug]` in the config tones it down).

Where: the profile's data folder, logs/ (debug.log_dir/<profile>/ if set)
("" — the profile's data dir, logs/):

    2026-10-16_15-04-12.log   the log: every request with its timing, polls, user
                     actions, errors with tracebacks, stats every few minutes. A new
                     file at every start and every hour (or debug.log_mb); the
                     oldest go once there are more than debug.keep_mb of them.
    latest.log       a link to the file being written — the one to send
    crash.log        Python's faulthandler: the stacks of all threads if the
                     process dies on a fatal signal (a segfault inside Qt, say)
    stacks.log       stacks of all threads on demand (`kill -USR1 <pid>`, the
                     menu, or by itself when the window freezes)

`python3 -m fedtail --bug-report` packs all that, plus versions and the config,
into one archive. The token (auth.json) and the database never go in. Logs
carry API paths, ids and timings, never post texts or the token.

No Qt in here: the frontend adds its own bits (Qt messages, a freeze watchdog)
through `add_stats()` and the module's loggers.
"""

import faulthandler
import gc
import io
import json
import logging
import logging.handlers
import os
import platform
import re
import shutil
import signal
import sys
import tarfile
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

try:
    import resource  # not on Windows
except ImportError:
    resource = None

log = logging.getLogger("fedtail.diag")

FORMAT = "%(asctime)s.%(msecs)03d %(levelname)-7s [%(threadName)s] %(name)s: %(message)s"
DATEFMT = "%Y-%m-%d %H:%M:%S"
LEVELS = {"debug": logging.DEBUG, "info": logging.INFO, "warning": logging.WARNING}

_state = {"dir": None, "stacks": None, "crash": None, "providers": {}, "stats_thread": None,
          "cpu": None, "rss_warned": 0, "on": True, "trend": None, "census": {},
          "census_on": False, "started": time.monotonic(), "last_stats": None}


def is_on():
    """The debugging mode of this run (after setup())."""
    return _state.get("on", True)


def enabled(cfg, forced=False):
    """Is the debugging mode on? debug.mode: "on", "off" or "auto" — on for
    development versions (X.Y.Z.devN, i.e. a git checkout between releases), off for
    releases and the one-file builds made from them. --debug turns it on whatever the
    config says."""
    if forced:
        return True
    mode = ((cfg or {}).get("debug") or {}).get("mode", "auto")
    if mode != "auto":
        return mode == "on"
    from . import __version__
    return ".dev" in __version__


def logs_dir(paths, cfg=None):
    """The profile's log folder: the one in use, or where debug.log_dir puts it.
    By default (and always with debugging off) the profile's data folder, logs/ —
    the menu opens it, nothing goes into the home folder."""
    if _state["dir"] is not None:
        return _state["dir"]
    where = ((cfg or {}).get("debug") or {}).get("log_dir", DEFAULT_LOG_DIR)
    if where == OLD_LOG_DIR:  # the default before 0.11, written into many configs
        where = DEFAULT_LOG_DIR
    if not where or (cfg is not None and not enabled(cfg)):
        return paths.data_dir / "logs"
    return Path(os.path.expanduser(where)) / paths.profile


DEFAULT_LOG_DIR = ""
OLD_LOG_DIR = "~/fedtail-logs"
# what a log folder holds that is ours to delete (nothing else in it is touched)
# (fedtail.log*: the single log file of the first versions)
OUR_LOGS = ("2[0-9][0-9][0-9]-*.log", "latest.log", "crash.log", "stacks.log", "version",
            "fedtail.log", "fedtail.log.[0-9]*", "memory-*.txt")


# the last day of the version before stays when a new one starts: an update is when one
# sends a report of what went wrong before it (the phone's 12:40 was gone at 19:26, 31.10)
KEEP_BEFORE_UPDATE_S = 24 * 3600


def _remove_ours(folder, keep_since=None):
    """Our log files in folder gone; the folder too if that leaves it empty. keep_since:
    a time — session logs written after it stay."""
    for pattern in OUR_LOGS:
        for f in folder.glob(pattern):
            try:
                if keep_since is not None and pattern == OUR_LOGS[0] and \
                        f.stat().st_mtime >= keep_since:
                    continue
                if f.is_symlink() or f.is_file():
                    f.unlink()
            except OSError:
                pass
    try:
        folder.rmdir()  # only when empty
    except OSError:
        pass


def _forget_old_logs(paths, folder):
    """Logs of another version go when a fresh one starts — but its last day stays (the
    report sent right after an update is about what went wrong before it). Also the
    logs the old default left in ~/fedtail-logs/<profile>/."""
    from . import version
    now = version.info()["version"].replace(" (dirty)", "")
    mark = folder / "version"
    try:
        before = mark.read_text("utf-8").strip()
    except OSError:
        before = None
    if before != now:
        if before is not None or any(folder.glob("2[0-9][0-9][0-9]-*.log")):
            import time
            _remove_ours(folder, keep_since=time.time() - KEEP_BEFORE_UPDATE_S)
            folder.mkdir(parents=True, exist_ok=True)
        try:
            mark.write_text(now + "\n", "utf-8")
        except OSError:
            pass
    old = Path(os.path.expanduser(OLD_LOG_DIR)) / paths.profile
    if old.is_dir() and old.resolve() != folder.resolve():
        _remove_ours(old)
        try:
            old.parent.rmdir()  # ~/fedtail-logs itself, once no profile is left in it
        except OSError:
            pass


class SessionLog(logging.Handler):
    """One file per start and per hour (and per log_mb): YYYY-MM-DD_HH-MM-SS.log,
    latest.log pointing at the current one; old files go once the folder holds
    more than keep_mb of them. Small files, easy to find, easy to send."""

    def __init__(self, folder, max_mb=10, keep_mb=500):
        super().__init__()
        self.folder = Path(folder)
        self.max_bytes = int(max_mb * 1024 * 1024)
        self.keep_bytes = int(keep_mb * 1024 * 1024)
        self.stream = None
        self.hour = None
        self.path = None
        self._open()

    def _open(self):
        if self.stream:
            self.stream.close()
        now = datetime.now()
        name = f"{now:%Y-%m-%d_%H-%M-%S}.log"
        n = 1
        while (self.folder / name).exists():  # two in one second: don't overwrite
            n += 1
            name = f"{now:%Y-%m-%d_%H-%M-%S}-{n}.log"
        self.path = self.folder / name
        self.path.touch()
        self._link_latest()
        self.stream = open(self.path, "a", encoding="utf-8")  # noqa: SIM115
        self.hour = now.strftime("%Y%m%d%H")
        self._prune()

    def _link_latest(self):
        """latest.log → the file being written: a symlink, or — where symlinks need a
        right nobody has (Windows without developer mode) — a hard link, the same file
        under a second name. Made before the file is opened for writing: Windows won't
        link a file someone holds open."""
        latest = self.folder / "latest.log"
        try:
            if latest.is_symlink() or latest.exists():
                latest.unlink()
        except OSError:  # held open elsewhere (an editor): the old one stays
            return
        try:
            latest.symlink_to(self.path.name)
        except OSError:
            try:
                os.link(self.path, latest)
            except OSError:  # neither (FAT, a network share): no latest.log
                pass

    def _prune(self):
        files = sorted((f for f in self.folder.glob("2[0-9][0-9][0-9]-*.log")
                        if f.is_file() and not f.is_symlink() and f != self.path),
                       key=lambda f: f.stat().st_mtime, reverse=True)
        total = self.path.stat().st_size if self.path and self.path.exists() else 0
        for f in files:
            total += f.stat().st_size
            if total > self.keep_bytes:
                try:
                    f.unlink()
                except OSError:
                    pass

    def emit(self, record):
        try:
            msg = self.format(record)
            if self.hour != datetime.now().strftime("%Y%m%d%H") or \
                    self.stream.tell() > self.max_bytes:
                self.stream.write("---- continued in the next file\n")
                self._open()
            self.stream.write(msg + "\n")
            self.stream.flush()
        except Exception:  # noqa: BLE001 — logging must never take the app down
            self.handleError(record)

    def close(self):
        try:
            if self.stream:
                self.stream.close()
                self.stream = None
        finally:
            super().close()


# ---- setup ---------------------------------------------------------------------------
_QUERY = re.compile(r"((?:https?://|url: |\s/)[^\s?'\"<>]*)\?[^\s'\"<>)]+")


def hide_queries(text):
    """An address's query out of a log line: what a request's error says ("…with url:
    /api/v2/search?q=what I looked for") or a picture's signed address. The API's own
    lines show their few paging parameters on their own (api._SAFE_PARAMS)."""
    return _QUERY.sub(r"\1?…", text)


class NoQueries(logging.Filter):
    """Every log line, whoever wrote it, without query strings (see hide_queries)."""

    def filter(self, record):
        msg = record.getMessage()
        if "?" in msg:
            record.msg, record.args = hide_queries(msg), None
        return True


def _own_folder(where):
    """A folder in the shared temporary one, made the owner's only (0700) — or refused
    (OSError) when someone else made it first or it's a link: another user of the machine
    must not read the logs, nor have them written where they say."""
    import stat
    where.mkdir(mode=0o700, exist_ok=True)
    st = os.lstat(where)
    if not stat.S_ISDIR(st.st_mode):
        raise OSError(f"{where}: not a folder")
    if hasattr(os, "getuid"):
        if st.st_uid != os.getuid():
            raise OSError(f"{where}: someone else's")
        if st.st_mode & 0o077:
            os.chmod(where, 0o700)


def _writable(folder, paths):
    """The log folder if it can be written to; else one in the temporary folder (a
    data folder made read-only, a full disk); None — nowhere at all."""
    import tempfile
    for where in (folder, Path(tempfile.gettempdir()) / f"fedtail-logs-{paths.profile}"):
        try:
            if where == folder:
                where.mkdir(parents=True, exist_ok=True)
            else:
                _own_folder(where)
            probe = where / ".write-test"
            probe.write_text("", "utf-8")
            probe.unlink()
            if where != folder:
                print(f"fedtail: {folder} can't be written to: the logs go to {where}",
                      file=sys.stderr)
            return where
        except OSError:
            continue
    return None


def setup(paths, cfg, console_debug=False):
    """Logging to session files (and warnings to the terminal), crash traces,
    stack dumps on SIGUSR1, uncaught exceptions of every thread into the log.
    With the debugging mode off (debug.mode): warnings and errors only, in the data
    folder, a few MB at most; crash traces stay."""
    d = cfg.get("debug", {})
    on = enabled(cfg, console_debug)
    _state["on"] = on
    _state["dir"] = None
    folder = _writable(logs_dir(paths, cfg), paths)
    if folder is not None:
        _forget_old_logs(paths, folder)
    _state["dir"] = folder

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(logging.DEBUG)
    fmt = logging.Formatter(FORMAT, DATEFMT)

    if folder is None:  # nowhere to write: the terminal alone (said there once)
        fh = None
    elif on:
        fh = SessionLog(folder, max_mb=d.get("log_mb", 10), keep_mb=d.get("keep_mb", 500))
        fh.setLevel(LEVELS.get(d.get("level", "debug"), logging.DEBUG))
    else:  # an ordinary user's run: what went wrong, nothing else
        fh = SessionLog(folder, max_mb=1, keep_mb=5)
        fh.setLevel(logging.WARNING)
    if fh is not None:
        fh.setFormatter(fmt)
        fh.addFilter(NoQueries())
        root.addHandler(fh)

    ch = logging.StreamHandler(sys.stderr)
    ch.setLevel(logging.DEBUG if console_debug else logging.WARNING)
    ch.setFormatter(logging.Formatter("fedtail: %(levelname)s %(name)s: %(message)s"))
    ch.addFilter(NoQueries())
    root.addHandler(ch)
    _state["console"] = ch
    # chatty libraries: their debug lines say nothing we don't log ourselves
    for name in ("urllib3", "requests", "PIL"):
        logging.getLogger(name).setLevel(logging.WARNING)

    if folder is None:
        print("fedtail: no folder for the logs can be written to: logging to the terminal "
              "only", file=sys.stderr)
        sys.excepthook = _excepthook
        threading.excepthook = _thread_excepthook
        return None
    # a fatal crash (segfault in Qt, say) still leaves the stacks behind
    _state["crash"] = open(folder / "crash.log", "a", encoding="utf-8")  # noqa: SIM115
    _state["crash"].write(f"\n=== {_stamp()} pid {os.getpid()} started\n")
    _state["crash"].flush()
    faulthandler.enable(file=_state["crash"], all_threads=True)
    _state["stacks"] = open(folder / "stacks.log", "a", encoding="utf-8")  # noqa: SIM115
    if hasattr(signal, "SIGUSR1"):
        try:
            faulthandler.register(signal.SIGUSR1, file=_state["stacks"], all_threads=True)
        except (ValueError, RuntimeError):  # not the main thread (tests)
            pass

    sys.excepthook = _excepthook
    threading.excepthook = _thread_excepthook
    return folder


_CTRL_C_WATCH = r"""
import os, signal, sys, threading, time
pid, wait, hint, gone = int(sys.argv[1]), float(sys.argv[2]), sys.argv[3], sys.argv[4]
first = []
done = threading.Event()

def ends():  # the program's end of the pipe closes as it ends, however it ends
    try:
        while sys.stdin.buffer.read(4096):
            pass
    finally:
        done.set()

def say():
    if not done.is_set():
        sys.stderr.write(hint + "\n")
        sys.stderr.flush()

def ctrl_c(*_a):
    now = time.monotonic()
    if not first:
        first.append(now)
        threading.Timer(wait, say).start()
    elif now - first[0] >= wait and not done.is_set():
        if hasattr(signal, "SIGUSR1"):  # its threads' stacks into stacks.log first
            try:
                os.kill(pid, signal.SIGUSR1)
                time.sleep(0.3)
            except OSError:
                pass
        sys.stderr.write(gone + "\n")
        sys.stderr.flush()
        try:
            os.kill(pid, getattr(signal, "SIGKILL", signal.SIGTERM))
        except OSError:
            pass
        os._exit(0)

signal.signal(signal.SIGINT, ctrl_c)
threading.Thread(target=ends, daemon=True).start()
while not done.wait(0.5):
    pass
os._exit(0)
"""
CTRL_C_WAIT = 3.0  # Ctrl+C, and the program still there this long: hung, say so


def watch_ctrl_c(on, hint, gone, wait=CTRL_C_WAIT):
    """Ctrl+C that works on a hung program (ui.ctrl_c_force). Python's own handler runs
    only in the main thread, holding Python's lock: a window stuck inside Qt with that
    lock held (a seek in the video player, 27.11) ignored Ctrl+C and the terminal's
    close alike, and only kill -9 ended it. A tiny process of its own beside it gets
    the terminal's Ctrl+C too: the program not gone `wait` seconds after the first, it
    says so (hint); one more Ctrl+C then dumps the stacks (stacks.log) and ends it
    (gone is said). It ends with the program — the pipe to it closes. Only in a
    terminal, and not from a one-file build (its Python can't run a script). The
    process, or None."""
    if not on or getattr(sys, "frozen", False) or sys.stdin is None or \
            not sys.stdin.isatty():
        return None
    import subprocess
    try:
        proc = subprocess.Popen(
            [sys.executable, "-I", "-S", "-c", _CTRL_C_WATCH, str(os.getpid()), str(wait),
             hint, gone], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, close_fds=True)
    except OSError as e:
        log.debug("Ctrl+C watch: %s", e)
        return None
    _state["ctrl_c"] = proc  # held: its stdin is the pipe that ends it with us
    return proc


def quiet_console():
    """No more log lines on the terminal: a full-screen terminal interface (the TUI) owns
    it, and a traceback printed over it scrambles the screen. The log file keeps them."""
    ch = _state.get("console")
    if ch is not None:
        logging.getLogger().removeHandler(ch)
        _state["console"] = None


# ---- what this process is: the interface it draws and, on a phone, the device -----------
# Said once at start (__main__ for the desktop's interfaces, the Android bridge for the
# phone); the session header, the bug report and the issue's draft all read it from here,
# so none of them says what the config wished instead of what runs (`--ui web` with
# ui.frontend = "qt", the phone).
_running = {"interface": "", "device": {}}
# a phone's facts fit for a public issue (the bug report, private, carries them all)
PUBLIC_DEVICE = ("android", "device", "abi", "screen", "app")


def running(interface, device=None):
    """Says what this process is.

    Args:
        interface: "qt", "gtk", "tui", "web", "cli" or "android".
        device: a phone's facts as its app gathers them ({"device": "Google Pixel 8",
            "android": "15 (API 35)", "abi", "memory", "screen", "app", …}); None on a
            desktop, where the system says it itself.
    """
    _running["interface"] = str(interface or "")
    _running["device"] = {str(k): str(v) for k, v in (device or {}).items() if v not in
                          (None, "")}


def interface(cfg=None):
    """The interface this process draws; before anyone said — the config's wish."""
    return _running["interface"] or ((cfg or {}).get("ui") or {}).get("frontend", "?")


def device():
    """A phone's facts (a copy), {} on a desktop."""
    return dict(_running["device"])


def system_lines(cfg=None, public=False):
    """The system in a few lines, the same wherever it's told: fedtail and Python, then a
    phone's model and Android or a desktop's OS and session, then the interface.
    public: only what may go into a public issue (a phone's memory, notifications and
    the like stay in the private report)."""
    from . import version
    lines = [f"fedtail {version.full()}", f"Python {platform.python_version()}"]
    dev = _running["device"]
    if dev:
        keys = PUBLIC_DEVICE if public else tuple(dev)
        lines += [f"{k} {dev[k]}" for k in keys if k in dev]
    else:
        lines += [f"{platform.system()} {platform.release()} ({platform.machine()})",
                  f"desktop {os.environ.get('XDG_CURRENT_DESKTOP', '') or '—'} "
                  f"{os.environ.get('XDG_SESSION_TYPE', '')}".strip()]
    lines.append(f"interface {interface(cfg)}")
    if getattr(sys, "frozen", False):
        lines.append("one-file build")
    return lines


def session_header(profile, extra=None):
    from . import version
    info = version.info()
    lines = {
        "fedtail": info["version"], "commit": info["commit"], "date": info["date"],
        "python": platform.python_version(), "platform": platform.platform(),
        "pid": os.getpid(), "profile": profile, "argv": " ".join(sys.argv[1:]),
        "desktop": os.environ.get("XDG_CURRENT_DESKTOP", ""),
        "session": os.environ.get("XDG_SESSION_TYPE", ""),
    }
    if _running["interface"]:
        lines["ui"] = _running["interface"]
    lines.update({k: v for k, v in _running["device"].items()})
    lines.update(extra or {})
    log.info("==== session start: %s", json.dumps(lines, ensure_ascii=False))


def earlier_crash(text):
    """A crash this side never saw — the phone's Kotlin (or Python thrown into it) closed
    the app; it left the trace in a file, told here on the next start: into crash.log and
    the session log, both in the bug report."""
    f = _state.get("crash")
    if f is not None:
        f.write(f"=== {_stamp()} the run before closed:\n{text.rstrip()}\n")
        f.flush()
    logging.getLogger("fedtail.crash").critical("the run before closed\n%s", text.rstrip())


def _stamp():
    return datetime.now().strftime(DATEFMT)


def _excepthook(kind, value, tb):
    logging.getLogger("fedtail.crash").critical(
        "uncaught exception\n%s", "".join(traceback.format_exception(kind, value, tb)))
    sys.__excepthook__(kind, value, tb)


def _thread_excepthook(args):
    logging.getLogger("fedtail.crash").critical(
        "uncaught exception in thread %s\n%s", args.thread.name if args.thread else "?",
        "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback)))


# ---- stacks on demand ----------------------------------------------------------------------
def thread_stacks():
    """Readable stacks of every thread, for the log."""
    names = {t.ident: t.name for t in threading.enumerate()}
    out = []
    for ident, frame in sys._current_frames().items():
        out.append(f"--- thread {names.get(ident, ident)}\n" +
                   "".join(traceback.format_stack(frame)))
    return "\n".join(out)


def dump_stacks(reason):
    """Into the log (readable) and stacks.log (faulthandler's raw form)."""
    log.warning("thread stacks (%s):\n%s", reason, thread_stacks())
    f = _state["stacks"]
    if f:
        f.write(f"\n=== {_stamp()} {reason}\n")
        f.flush()
        faulthandler.dump_traceback(file=f, all_threads=True)
        f.flush()


# ---- resource stats ------------------------------------------------------------------------
def add_stats(name, fn):
    """fn() -> {key: number}; logged with every stats line (the core's caches,
    the window's widget count, …). Errors in a provider are logged, not raised."""
    _state["providers"][name] = fn


def _windows_memory():
    """{"VmRSS", "VmHWM"} in kB from GetProcessMemoryInfo — Windows' /proc/self/status."""
    import ctypes
    from ctypes import wintypes

    class Counters(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
    c = Counters()
    c.cb = ctypes.sizeof(c)
    k32 = ctypes.windll.kernel32
    k32.GetCurrentProcess.restype = wintypes.HANDLE
    get = getattr(k32, "K32GetProcessMemoryInfo", None) or ctypes.windll.psapi.GetProcessMemoryInfo
    get.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
    get.restype = wintypes.BOOL
    if not get(k32.GetCurrentProcess(), ctypes.byref(c), c.cb):
        return {}
    return {"VmRSS": c.WorkingSetSize // 1024, "VmHWM": c.PeakWorkingSetSize // 1024}


def _fd_kinds():
    """Open files by kind (socket, pipe, anon_inode, file…): sockets piling up is a
    connection not closed, files piling up a file not closed."""
    kinds = {}
    for fd in os.listdir("/proc/self/fd"):
        try:
            target = os.readlink(f"/proc/self/fd/{fd}")
        except OSError:
            continue
        kind = target.split(":", 1)[0] if ":" in target and not target.startswith("/") \
            else ("dev" if target.startswith("/dev/") else "file")
        kinds[kind] = kinds.get(kind, 0) + 1
    return kinds


_LIBC = {}


def _libc():
    """The C library (glibc's libc.so.6, Android's bionic libc.so), or None."""
    if "lib" not in _LIBC:
        _LIBC["lib"] = None
        try:
            import ctypes
        except ImportError:
            return None
        for name in ("libc.so.6", "libc.so"):
            try:
                _LIBC["lib"] = ctypes.CDLL(name)
                break
            except OSError:
                continue
    return _LIBC["lib"]


M_PURGE, M_PURGE_ALL = -101, -104  # bionic's mallopt: free pages back (Android 10+, 12+)


def _give_back(libc):
    """The allocator's free memory back to the system: glibc's malloc_trim, bionic's
    mallopt(M_PURGE_ALL / M_PURGE) — the phone held all it ever took (08.11). True
    when there was such a call."""
    try:
        libc.malloc_trim(0)
        return True
    except AttributeError:
        pass
    try:
        mallopt = libc.mallopt
    except AttributeError:
        return False
    if not mallopt(M_PURGE_ALL, 0):  # Android 12+; before it, M_PURGE
        mallopt(M_PURGE, 0)
    return True


def trim_memory():
    """Memory Python and Qt freed back to the system (glibc keeps it otherwise: after a
    night of lanes built and let go, the process stays at its peak). Returns the MB the
    resident size went down by, or None where there's no such call."""
    libc = _libc()
    if libc is None:
        return None
    before = _proc_status().get("VmRSS") or 0
    gc.collect()
    if not _give_back(libc):
        return None
    after = _proc_status().get("VmRSS") or 0
    return round((before - after) / 1024, 1)


_soon = {"at": 0.0, "why": "", "thread": None, "lock": threading.Lock(),
         "wake": threading.Event()}
TRIM_AFTER_S = 5.0


def trim_soon(why=""):
    """Memory back to the system a few seconds after the window let a lot of it go —
    cards scrolled past, a lane unloaded, a tab closed — and not only at the next stats
    tick: smem right after reading through lanes saw the freed memory still held (29.10:
    145 → 387 MB; the tick 5 minutes later gave 81 MB back). Waits for things to settle
    (each call puts it off again; one thread waits for all of them), off the window's
    thread, without a gc pass (malloc_trim lets go of the GIL; a gc pass wouldn't).
    Off with debug.trim_memory."""
    if not _state.get("trim_on", True):
        return
    with _soon["lock"]:
        _soon["at"] = time.monotonic() + TRIM_AFTER_S
        _soon["why"] = why or "let go"
        if _soon["thread"] is None:
            t = threading.Thread(target=_trim_waiter, name="fedtail-trim-soon",
                                 daemon=True)
            _soon["thread"] = t
            t.start()
    _soon["wake"].set()


def _trim_waiter():
    while True:
        _soon["wake"].wait()
        while True:
            with _soon["lock"]:
                left = _soon["at"] - time.monotonic()
                if left <= 0:
                    _soon["wake"].clear()
                    why = _soon["why"]
                    break
            time.sleep(min(left, TRIM_AFTER_S))
        try:
            freed = _malloc_trim()
        except Exception:  # noqa: BLE001 — a nicety, never a crash
            log.debug("trim failed", exc_info=True)
            continue
        if freed:
            log.debug("memory: %.1f MB given back (%s)", freed, why)


def _malloc_trim():
    """The allocator's trim alone (no gc pass): the MB the resident size went down by,
    or None."""
    libc = _libc()
    if libc is None:
        return None
    before = _proc_status().get("VmRSS") or 0
    if not _give_back(libc):
        return None
    after = _proc_status().get("VmRSS") or 0
    return round((before - after) / 1024, 1)


def _proc_status():
    out = {}
    if os.name == "nt":
        try:
            return _windows_memory()
        except Exception:  # noqa: BLE001 — stats are a nicety
            return {}
    try:
        for line in Path("/proc/self/status").read_text().splitlines():
            key, _sep, val = line.partition(":")
            if key in ("VmRSS", "VmHWM", "Threads"):
                out[key] = int(val.split()[0])
    except OSError:
        pass
    return out


def smaps():
    """{"uss_mb", "pss_mb"} of this process (Linux: /proc/self/smaps_rollup); {} elsewhere.
    USS — the pages only this process has, what it would give back: the number that
    says how heavy fedtail itself is (RSS counts the shared libraries whole)."""
    try:
        text = Path("/proc/self/smaps_rollup").read_text()
    except OSError:
        return {}
    kb = {}
    for line in text.splitlines():
        key, _sep, rest = line.partition(":")
        parts = rest.split()
        if parts and parts[0].isdigit():
            kb[key.strip()] = int(parts[0])
    out = {}
    uss = kb.get("Private_Clean", 0) + kb.get("Private_Dirty", 0)
    if uss:
        out["uss_mb"] = round(uss / 1024, 1)
    if "Pss" in kb:
        out["pss_mb"] = round(kb["Pss"] / 1024, 1)
    return out


# where a mapping of /proc/self/smaps goes in the breakdown (memory_map), by its name
_MAP_NAMED = (("[heap]", "heap"), ("[stack", "stack"), ("[anon:stack", "stack"),
              ("[anon:dalvik", "java"), ("[anon:art", "java"), ("/dev/ashmem/dalvik", "java"),
              ("[anon:scudo", "native"), ("[anon:libc_malloc", "native"),
              ("[anon:jemalloc", "native"), ("[anon:thread", "stack"),
              ("/dev/dri", "gpu"), ("/dev/kgsl", "gpu"), ("/dev/mali", "gpu"),
              ("/dmabuf", "gpu"), ("/memfd:", "memfd"), ("/dev/shm", "memfd"))
_CODE_ENDS = (".odex", ".oat", ".art", ".vdex", ".apk", ".jar", ".dex")


def _map_kind(name):
    if not name:
        return "anon"  # malloc's other arenas, its big blocks, Python's arenas, Qt's
    for start, kind in _MAP_NAMED:
        if name.startswith(start):
            return kind
    if name.startswith("[anon:"):
        return "anon"
    if name.startswith("["):
        return "other"  # [vdso], [vvar]…
    base = name.rsplit("/", 1)[-1]
    if ".so" in base:
        return "libs"
    if base.endswith(_CODE_ENDS):
        return "code"
    return "files"  # the database's pages, fonts, icon themes…


def memory_map(text=None, top=6):
    """Where this process's own memory lies (debug.memory_map): the private pages (USS)
    of each kind of mapping in /proc/self/smaps — the main heap, the other anonymous
    memory (malloc's other arenas and big blocks, Python's arenas, Qt's), stacks, the
    libraries' own pages, files, the graphics driver's; on Android also ART's Java heap
    and the native heap — and the libraries with the most of it. {} where there is no
    smaps (not Linux, not Android). A night's growth said only "rss_mb 337->938"
    (08.11): this says which part grew."""
    if text is None:
        try:
            text = Path("/proc/self/smaps").read_text()
        except OSError:
            return {}
    kinds, libs, kind, lib = {}, {}, None, None
    for line in text.splitlines():
        head = line.split(None, 5)
        if head and "-" in head[0] and len(head) >= 5 and ":" not in head[0]:
            name = head[5].strip() if len(head) > 5 else ""
            kind = _map_kind(name)
            lib = name.rsplit("/", 1)[-1] if kind == "libs" else None
            continue
        if kind is None or not line.startswith(("Private_Clean:", "Private_Dirty:")):
            continue
        kb = int(line.split()[1])
        kinds[kind] = kinds.get(kind, 0) + kb
        if lib:
            libs[lib] = libs.get(lib, 0) + kb
    out = {f"mem.{k}_mb": round(v / 1024, 1) for k, v in sorted(kinds.items())}
    if libs:
        out["mem_libs"] = {k: round(v / 1024, 1) for k, v in
                           sorted(libs.items(), key=lambda kv: -kv[1])[:top]
                           if v >= 512}  # half a MB and more: the ones that matter
    return out


def malloc_info():
    """The C allocator's own account (glibc's mallinfo2, bionic's mallinfo), MB: used —
    handed out now; free — freed but still held (what a trim can give back, and what
    fragmentation keeps); mmap — big blocks of their own; arena — the heap it grew.
    {} where it can't say."""
    libc = _libc()
    if libc is None:
        return {}
    import ctypes

    class Info(ctypes.Structure):
        _fields_ = [(f, ctypes.c_size_t) for f in (
            "arena", "ordblks", "smblks", "hblks", "hblkhd", "usmblks", "fsmblks",
            "uordblks", "fordblks", "keepcost")]
    fn = getattr(libc, "mallinfo2", None)
    if fn is None and (sys.platform == "android" or "ANDROID_ROOT" in os.environ):
        fn = getattr(libc, "mallinfo", None)  # bionic's: size_t fields already
    if fn is None:
        return {}
    fn.restype = Info
    try:
        m = fn()
    except Exception:  # noqa: BLE001 — a nicety
        return {}
    mb = lambda n: round(n / 1024 / 1024, 1)  # noqa: E731
    return {"malloc.used_mb": mb(m.uordblks), "malloc.free_mb": mb(m.fordblks),
            "malloc.mmap_mb": mb(m.hblkhd), "malloc.arena_mb": mb(m.arena)}


def stats():
    """One snapshot: memory, CPU since the last snapshot, threads, files, providers."""
    now = time.monotonic()
    cpu = time.process_time()  # user + system time of this process, on every system
    maxrss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss if resource else 0
    prev = _state["cpu"]
    _state["cpu"] = (now, cpu)
    st = _proc_status()
    rss_mb = round((st.get("VmRSS") or maxrss) / 1024, 1)
    out = {
        "rss_mb": rss_mb,
        **smaps(),
        "peak_mb": round(st.get("VmHWM", maxrss) / 1024, 1),
        "cpu_s": round(cpu, 1),
        "py_objects": len(gc.get_objects()),  # growing for hours: Python-side leak
        "cpu_pct": round(100 * (cpu - prev[1]) / max(now - prev[0], 1e-6), 1) if prev else None,
        "threads": threading.active_count(),
    }
    if _state.get("map_on", True):  # which part of it (debug.memory_map)
        try:
            out.update(memory_map())
            out.update(malloc_info())
            out["py.blocks"] = sys.getallocatedblocks()  # Python's own allocations
        except Exception as e:  # noqa: BLE001 — stats are a nicety
            out["mem.error"] = str(e)[:80]
    from . import leaks
    for k, v in leaks.gc_stats().items():
        out[f"gc.{k}"] = v
    try:
        out["fds"] = len(os.listdir("/proc/self/fd"))
        out["fds_by_kind"] = _fd_kinds()
    except OSError:
        pass
    for name, fn in list(_state["providers"].items()):
        try:
            for k, v in (fn() or {}).items():
                out[f"{name}.{k}"] = v
        except Exception as e:  # noqa: BLE001 — a broken provider must not break the stats
            out[f"{name}.error"] = str(e)[:80]
    return out


def log_stats(rss_warn_mb=1500):
    s = stats()
    _state["last_stats"] = s
    log.info("stats %s", json.dumps(s, ensure_ascii=False))
    rss = s["rss_mb"]
    # warn once per doubling past the threshold, so a leak is visible but not spammy
    if rss_warn_mb and rss > rss_warn_mb and rss > 2 * _state["rss_warned"]:
        _state["rss_warned"] = rss
        log.warning("memory: %s MB resident (warning threshold %s MB)", rss, rss_warn_mb)
    return s


def moment(name, **extra):
    """A snapshot of the memory at a moment worth comparing — "reading began" (the first
    read mark after an hour's quiet: the night's in it), "reading ended" — into the log,
    for the night's summary (night_summary, in every bug report). smem's numbers: USS,
    PSS, RSS."""
    st = _proc_status()
    snap = {"rss_mb": round((st.get("VmRSS") or 0) / 1024, 1), **smaps(), **extra}
    log.info("moment %s %s", name, json.dumps(snap, ensure_ascii=False))
    return snap


_LINE = re.compile(r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\.\d+ (\w+)\s+\[[^\]]*\] [\w.]+: (.*)$")


def night_summary(texts):
    """The logs of a night (or any stretch) in a few lines, for the morning's bug
    report (summary.md): how long it ran, the memory at its start, lowest, highest and
    last (USS / PSS / RSS, as smem), the moments (reading began / ended) with theirs, the
    freezes, the rounds, the warnings and errors. texts: the log files' texts, oldest
    first."""
    stats_, moments, frozen, warn, err, rounds = [], [], [], 0, 0, 0
    first = last = None
    for text in texts:
        for line in text.splitlines():
            m = _LINE.match(line)
            if not m:
                continue
            when, level, msg = m.groups()
            first = first or when
            last = when
            if level == "WARNING":
                warn += 1
            elif level in ("ERROR", "CRITICAL"):
                err += 1
            if msg.startswith("stats {"):
                try:
                    stats_.append((when, json.loads(msg[6:])))
                except ValueError:
                    pass
            elif msg.startswith("moment "):
                name, _, data = msg[7:].partition(" {")
                try:
                    moments.append((when, name, json.loads("{" + data)))
                except ValueError:
                    pass
            elif msg.startswith("GUI froze "):
                frozen.append((when, msg[10:].split(":")[0]))
            elif msg.startswith("poll #"):
                rounds += 1
    out = ["# The night in short", ""]
    if not first:
        return "\n".join(out + ["Nothing in the logs.", ""])
    out.append(f"From {first} to {last}.")
    if stats_:
        def row(key):
            vals = [s.get(key) for _w, s in stats_ if isinstance(s.get(key), (int, float))]
            if not vals:
                return None
            return f"| {key} | {vals[0]} | {min(vals)} | {max(vals)} | {vals[-1]} |"
        rows = [r for r in (row("uss_mb"), row("pss_mb"), row("rss_mb")) if r]
        out += ["", "| MB | at start | lowest | highest | last |", "|---|---|---|---|---|", *rows]
        polls = [s.get("core.polls") for _w, s in stats_ if s.get("core.polls") is not None]
        if polls:
            rounds = max(rounds, polls[-1] if isinstance(polls[-1], int) else rounds)
    if moments:
        out += ["", "| when | moment | USS | PSS | RSS |", "|---|---|---|---|---|"]
        out += [f"| {w} | {n} | {d.get('uss_mb', '—')} | {d.get('pss_mb', '—')} | "
                f"{d.get('rss_mb', '—')} |" for w, n, d in moments]
    out += ["", f"Freezes: {len(frozen)}" + (", the worst " + max(
        (f for _w, f in frozen), key=lambda f: int(f.split()[0]) if f.split()[0].isdigit()
        else 0) if frozen else ""), f"Rounds: {rounds}",
        f"Warnings: {warn}, errors: {err}", ""]
    return "\n".join(out)


def census(name, counts):
    """Counts by kind (see leaks.Census): logged against the last and the first count
    of that name. The window feeds its widget classes here from the GUI thread."""
    from . import leaks
    c = _state["census"].get(name)
    if c is None:
        c = _state["census"][name] = leaks.Census(name)
    return c.take(counts)


def trend(s):
    """One stats snapshot into the leak watch: warnings (logged) and a summary line."""
    t = _state["trend"]
    if t is None:
        return []
    warnings = t.add(s)
    log.info("trend over %.1f h %s", t.hours(), json.dumps(t.summary(), ensure_ascii=False))
    return warnings


def check_now(rss_warn_mb=1500, objects=None):
    """Stats, trend and (in the debugging mode, or when asked) the Python object census,
    now — the stats thread's job, also run from the Debug menu."""
    from . import leaks
    s = log_stats(rss_warn_mb)
    trend(s)
    if objects if objects is not None else _state["census_on"]:
        t = time.monotonic()
        census("python", leaks.python_objects())
        log.debug("census python took %.0f ms", (time.monotonic() - t) * 1000)
    return s


def session_summary():
    """The last line of a session: how long, how big it got, what grew."""
    t = _state["trend"]
    s = _state["last_stats"] or {}
    st = _proc_status()
    hours = (time.monotonic() - _state["started"]) / 3600
    bits = {"hours": round(hours, 2), "rss_mb": round((st.get("VmRSS") or 0) / 1024, 1),
            "peak_mb": round((st.get("VmHWM") or 0) / 1024, 1),
            "cpu_s": round(time.process_time(), 1)}
    for k in ("freezes.count", "freezes.worst_ms", "core.polls"):
        if k in s:
            bits[k] = s[k]
    log.info("session summary %s", json.dumps(bits, ensure_ascii=False))
    if t is not None and t.history:
        log.info("session trend %s", json.dumps(t.summary(), ensure_ascii=False))
    return bits


def start_stats(cfg):
    d = cfg.get("debug", {})
    minutes = float(d.get("stats_minutes", 5))
    if _state["stats_thread"]:
        return
    from . import leaks
    _state["trend"] = leaks.Trend(int(d.get("leak_samples", 12)))
    _state["census_on"] = bool(d.get("object_census", True)) and is_on()
    _state["trim_on"] = bool(d.get("trim_memory", True))
    _state["map_on"] = bool(d.get("memory_map", True))
    if d.get("tracemalloc", False):
        leaks.start_tracing()
    if minutes <= 0 or not _state.get("on", True):
        if d.get("trim_memory", True):  # no stats, but the memory still goes back
            def trim_loop():
                while True:
                    time.sleep(600)
                    try:
                        trim_memory()
                    except Exception:  # noqa: BLE001 — a nicety, never a crash
                        log.debug("trim failed", exc_info=True)
            t = threading.Thread(target=trim_loop, name="fedtail-trim", daemon=True)
            _state["stats_thread"] = t
            t.start()
        return

    def loop():
        stats()  # baseline for the CPU percentage
        while True:
            time.sleep(minutes * 60)
            try:
                if d.get("trim_memory", True):
                    freed = trim_memory()
                    if freed:
                        log.info("memory: %.1f MB given back to the system", freed)
                check_now(int(d.get("rss_warn_mb", 1500)))
            except Exception:
                log.exception("stats failed")

    t = threading.Thread(target=loop, name="fedtail-stats", daemon=True)
    _state["stats_thread"] = t
    t.start()


# ---- freeze watchdog --------------------------------------------------------------------------
def gui_stuck_for():
    """Seconds since the window's thread last beat its watchdog; 0 without one (the
    terminal, the web page: nothing known to be stuck)."""
    dog = _state.get("watchdog")
    if dog is None or dog._stop.is_set():
        return 0.0
    return max(0.0, time.monotonic() - dog.last)


class Watchdog:
    """The GUI thread calls beat() every second (from a timer). If the beats stop
    for `seconds`, the stacks of all threads go to the log once — that is where
    a hang shows what it was waiting on — and recovery is logged too."""

    def __init__(self, seconds):
        self.seconds = seconds
        self.last = time.monotonic()
        self.stuck_since = None
        self._stop = threading.Event()
        _state["watchdog"] = self  # gui_stuck_for: the single instance asks it

    def beat(self):
        now = time.monotonic()
        if self.stuck_since is not None:
            log.warning("GUI thread responsive again after %.1f s", now - self.stuck_since)
            self.stuck_since = None
        self.last = now

    def start(self):
        if self.seconds <= 0:
            return
        threading.Thread(target=self._run, name="fedtail-watchdog", daemon=True).start()

    def stop(self):
        self._stop.set()
        if _state.get("watchdog") is self:
            _state["watchdog"] = None

    def _run(self):
        while not self._stop.wait(1.0):
            idle = time.monotonic() - self.last
            if idle > self.seconds and self.stuck_since is None:
                self.stuck_since = self.last
                dump_stacks(f"GUI thread hasn't answered for {idle:.1f} s")


# ---- freezes of the GUI thread ----------------------------------------------------------
# where the toolkit's loop runs (app.exec(), app.run()): a stack ending there is the
# toolkit's own work — laying out, painting, shaping text
EVENT_LOOP = ("frontends/qt/__init__.py", "frontends/gtk/__init__.py")
_busy = []  # what the GUI thread is doing now, outermost first (labels from busy())


class busy:
    """with diag.busy("lane home: draw"): …  — names what the GUI thread is doing, so
    a freeze in the log says which of our jobs it fell into."""

    def __init__(self, label):
        self.label = label

    def __enter__(self):
        _busy.append(self.label)
        return self

    def __exit__(self, *_):
        if _busy and _busy[-1] == self.label:
            _busy.pop()
        return False


def _short_stack(frame, depth=10):
    """The innermost frames as "file.py:123 func", innermost last."""
    out = []
    for fs in traceback.extract_stack(frame)[-depth:]:
        name = fs.filename.replace("\\", "/")
        if "/fedtail/" in name:
            name = "fedtail/" + name.rsplit("/fedtail/", 1)[1]
        else:
            name = name.rsplit("/", 1)[-1]
        out.append(f"{name}:{fs.lineno} {fs.name}")
    return out


class StallMeter:
    """Freezes shorter than the watchdog's seconds: the GUI thread calls tick() from a
    timer every `interval` s; a thread of its own notices when the ticks stop for more
    than `stall_ms` and looks at what the GUI thread is busy with right then — the
    Python stack and the busy() labels — a few times during a long one. When the ticks
    come back, one line says how long the window froze and where. A stack that ends
    in the event loop means Qt itself was busy: laying out, painting, shaping text."""

    SAMPLES_AT = (1, 3, 8)  # in units of stall_ms into the freeze

    def __init__(self, stall_ms, interval=0.1):
        self.stall = stall_ms / 1000.0
        self.interval = interval
        self.last = time.monotonic()
        self.gui = threading.get_ident()
        self.samples = []
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self.count = 0
        self.total_ms = 0.0
        self.worst_ms = 0.0

    def start(self):
        if self.stall <= 0:
            return
        self.gui = threading.get_ident()
        threading.Thread(target=self._run, name="fedtail-stalls", daemon=True).start()

    def stop(self):
        self._stop.set()

    def tick(self):
        now = time.monotonic()
        gap = now - self.last - self.interval
        self.last = now
        with self._lock:
            samples, self.samples = self.samples, []
        if self.stall <= 0 or gap < self.stall:
            return
        ms = gap * 1000
        self.count += 1
        self.total_ms += ms
        self.worst_ms = max(self.worst_ms, ms)
        where, seen = [], set()
        for labels, stack in samples:
            key = (tuple(labels), tuple(stack[-4:]))
            if key in seen:
                continue
            seen.add(key)
            inside = " > ".join(labels) or "-"
            frames = " <- ".join(reversed(stack)) if stack else "?"
            if stack and not labels and any(e in stack[-1] for e in EVENT_LOOP):
                inside = "the toolkit itself (layout, painting, text)"
            where.append(f"[{inside}] {frames}")
        log.warning("GUI froze %.0f ms%s", ms,
                    (": " + " || ".join(where)) if where else " (not caught in the act)")

    def _run(self):
        taken = 0
        while not self._stop.wait(0.05):
            late = time.monotonic() - self.last - self.interval
            if late < self.stall:
                taken = 0
                continue
            if taken < len(self.SAMPLES_AT) and late >= self.stall * self.SAMPLES_AT[taken]:
                taken += 1
                frame = sys._current_frames().get(self.gui)
                sample = (list(_busy), _short_stack(frame) if frame is not None else [])
                with self._lock:
                    self.samples.append(sample)

    def counts(self):
        return {"count": self.count, "total_ms": round(self.total_ms),
                "worst_ms": round(self.worst_ms)}


# ---- timing helper ------------------------------------------------------------------------------
class timed:
    """with timed("poll", warn_s=30): …  — debug line with the duration, a warning
    if it took longer than warn_s."""

    def __init__(self, what, logger=None, warn_s=None):
        self.what, self.log, self.warn_s = what, logger or log, warn_s

    def __enter__(self):
        self.t = time.monotonic()
        return self

    def __exit__(self, kind, *_):
        self.seconds = time.monotonic() - self.t
        level = logging.WARNING if self.warn_s and self.seconds > self.warn_s else logging.DEBUG
        self.log.log(level, "%s took %.2f s%s", self.what, self.seconds,
                     " (failed)" if kind else "")
        return False


def _toolkits():
    """The toolkits loaded in this process, with their versions (only those already
    imported: asking must not load one)."""
    out = []
    qt = sys.modules.get("PySide6.QtCore")  # asked of what is loaded: no import here
    if qt is not None:
        try:
            out.append(f"Qt {qt.qVersion()}")
        except Exception:  # noqa: BLE001
            pass
    gi = sys.modules.get("gi.repository.Gtk")
    if gi is not None:
        try:
            out.append(f"GTK {gi.get_major_version()}.{gi.get_minor_version()}."
                       f"{gi.get_micro_version()}")
            adw = sys.modules.get("gi.repository.Adw")
            out.append(f"libadwaita {adw.get_major_version()}.{adw.get_minor_version()}"
                       if adw is not None else "libadwaita not used")
        except Exception:  # noqa: BLE001
            pass
    if "textual" in sys.modules:
        out.append(f"textual {getattr(sys.modules['textual'], '__version__', '?')}")
    return out


# options whose value is a secret: never in a log or a report as it is (redact)
SECRET_OPTIONS = {"translate_key"}
_USERINFO = re.compile(r"(?i)\b([a-z][a-z0-9+.-]*://)[^/@\s\"']+@")
_SECRET_LINE = re.compile(r"(?m)^(\s*(?:" + "|".join(sorted(SECRET_OPTIONS)) +
                          r")\s*=\s*)(\"[^\"\n]*\"|'[^'\n]*')")


def redact(value):
    """A value as a log or a report may hold it: a URL's user and password ("socks5h://
    me:pw@host" — net.proxy, a WebDAV address) taken out, whatever the option."""
    if isinstance(value, str):
        return _USERINFO.sub(r"\1***@", value)
    if isinstance(value, list):
        return [redact(v) for v in value]
    if isinstance(value, dict):
        return {k: "***" if k in SECRET_OPTIONS and v else redact(v)
                for k, v in value.items()}
    return value


def redact_config(text):
    """config.toml's text for a log or a report: the secret options' values (an API key)
    and every URL's user and password replaced by ***, the rest as it is."""
    text = _SECRET_LINE.sub(lambda m: m.group(1) + ('"***"' if len(m.group(2)) > 2
                                                     else m.group(2)), text)
    return _USERINFO.sub(r"\1***@", text)


SETS_TABLES = ("sets", "words", "sections", "renamed", "about", "switches")  # core/presets.TABLES


def changed_options(cfg):
    """{"section.key": value} of the options that differ from the defaults (secrets
    redacted: SECRET_OPTIONS, a URL's password)."""
    from .core.config import DEFAULTS
    out = {}
    for section, values in (cfg or {}).items():
        base = DEFAULTS.get(section)
        if not isinstance(values, dict) or not isinstance(base, dict):
            continue
        for key, val in values.items():
            if section == "lanes" and key in SETS_TABLES:
                continue  # the sets of lanes and their words: tables, not options
            if key not in base or base[key] != val:
                out[f"{section}.{key}"] = "***" if key in SECRET_OPTIONS and val \
                    else redact(val)
    return out


def debug_context(paths, cfg, ui):
    """In the debugging mode (a dev version): what --bug-report would add, written into
    the log right away — so the log file alone is enough to send. The system summary,
    the options changed from the defaults and the config file itself (it holds no
    token; auth.json and the database never go anywhere)."""
    if not is_on():
        return
    log.info("==== for a bug report (the debugging mode: this log alone is enough)\n"
             "frontend %s\n%s", ui, _system_summary(paths).rstrip())
    log.info("options changed from the defaults: %s",
             json.dumps(changed_options(cfg), ensure_ascii=False, default=str))
    try:
        text = paths.config_file.read_text("utf-8")
    except OSError:
        text = ""
    if text.strip():
        log.info("config file %s:\n%s", paths.config_file, redact_config(text).rstrip())


# ---- bug report ----------------------------------------------------------------------------------
# sync_auth.json: 0.21's sync login (a token) — gone since, but a profile may still hold one
REPORT_SKIP = {"auth.json", "login.json", "state.db", "state.db-wal", "state.db-shm", "sync.key",
               "sync_auth.json", "sync_invite.json", "sync_webdav.json"}


def full_snapshot(paths, cfg=None, census=None, dest_dir=None):
    """Debug ▸ "a full snapshot into an archive": everything one could ask for, in one
    step — the threads' stacks, the stats, the census of objects (and of the toolkit's
    widgets: census()), the memory snapshot when tracing is on — all into the log, then
    the report (bug_report) with the logs, the config and the system. One item instead
    of the menu's eight (stacks, census, trim, tracing, snapshot, folders…, 29.10).
    Returns the archive."""
    from . import leaks
    d = (cfg or {}).get("debug", {}) if isinstance(cfg, dict) else {}
    dump_stacks("full snapshot")
    try:
        check_now(int(d.get("rss_warn_mb", 1500)), objects=True)
        if census is not None:
            census()
    except Exception:  # noqa: BLE001 — the census is a help; the archive comes anyway
        log.exception("full snapshot: census")
    if leaks.tracing():
        try:
            leaks.snapshot(logs_dir(paths, cfg))
        except (OSError, RuntimeError) as e:
            log.warning("full snapshot: memory: %s", e)
    log_stats(int(d.get("rss_warn_mb", 1500)))
    return bug_report(paths, dest_dir, cfg)


# what a running core adds to a report: {file name: fn() -> text} (the core registers
# its unread census — which posts each lane counts unread, ids only: two devices'
# counts that differ are compared post by post, 31.10)
_REPORT_EXTRAS = {}


def report_extra(name, fn):
    """fn() → the text of `name` in the next bug report (None: none any more)."""
    if fn is None:
        _REPORT_EXTRAS.pop(name, None)
    else:
        _REPORT_EXTRAS[name] = fn


def bug_report(paths, dest_dir=None, cfg=None, hours=48):
    """A .tar.gz with the logs of the last `hours`, crash and stack files, the config
    and a system summary. Never the token or the database. Returns the archive path."""
    dest = Path(dest_dir or Path.home())
    name = f"fedtail-report-{paths.profile}-{datetime.now():%Y%m%d-%H%M%S}.tar.gz"
    out = dest / name
    folder = logs_dir(paths, cfg)
    since = time.time() - hours * 3600
    summary = _system_summary(paths, cfg)
    with tarfile.open(out, "w:gz") as tar:
        if folder.exists():
            for f in sorted(folder.iterdir()):
                # latest.log: the link (a hard one on Windows), not a second copy
                if f.is_file() and not f.is_symlink() and f.name not in REPORT_SKIP \
                        and f.name != "latest.log" \
                        and (not f.name[:1].isdigit() or f.stat().st_mtime >= since):
                    tar.add(f, arcname=f"logs/{f.name}")
        # the night in short (night_summary): what a morning's report is read for first
        texts = []
        if folder.exists():
            for f in sorted(folder.iterdir()):
                if f.is_file() and f.suffix == ".log" and f.name[:1].isdigit() \
                        and f.stat().st_mtime >= since:
                    try:
                        texts.append(f.read_text("utf-8", "replace"))
                    except OSError:
                        pass
        _add_text(tar, "summary.md", night_summary(texts))
        if paths.config_file.exists():  # its secrets redacted (an API key, a proxy's password)
            _add_text(tar, "config.toml", redact_config(paths.config_file.read_text("utf-8")))
        _add_text(tar, "system.txt", summary)
        for extra, fn in list(_REPORT_EXTRAS.items()):
            try:
                _add_text(tar, extra, fn())
            except Exception as e:  # noqa: BLE001 — the report goes without it
                log.info("report: %s: %s", extra, e.__class__.__name__)
    return out


def _add_text(tar, name, text):
    data = text.encode("utf-8")
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mtime = int(time.time())
    tar.addfile(info, io.BytesIO(data))


def _system_summary(paths, cfg=None):
    lines = system_lines(cfg) + [
             f"python {sys.version}", f"platform {platform.platform()}",
             f"profile {paths.profile}", f"config {paths.config_file}",
             f"data {paths.data_dir}"]
    for mod in ("PySide6", "requests", "urllib3"):
        try:
            m = __import__(mod)
            lines.append(f"{mod} {getattr(m, '__version__', '?')}")
        # a module that fails to import is what this line reports
        except Exception as e:  # noqa: BLE001
            lines.append(f"{mod} missing ({e.__class__.__name__})")
    lines += _toolkits()
    try:
        lines.append(f"state.db {paths.db_file.stat().st_size // 1024} KB")
    except OSError:
        pass
    try:
        usage = shutil.disk_usage(paths.data_dir)
        lines.append(f"disk free {usage.free // (1024 * 1024)} MB")
    except OSError:
        pass
    lines.append("stats " + json.dumps(stats(), ensure_ascii=False))
    return "\n".join(lines) + "\n"

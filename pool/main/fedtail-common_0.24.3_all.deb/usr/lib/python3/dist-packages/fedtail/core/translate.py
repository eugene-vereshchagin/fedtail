"""Translation: on a click (the server's /translate, or LibreTranslate), and by itself
(feed.translate_auto) for posts in languages I neither read nor write."""

import logging
from html import escape as html_escape
from typing import Any

import requests

from ..version import USER_AGENT
from . import proto, remote
from .model import real
from .proto import raw
from .state import CoreState

log = logging.getLogger("fedtail.core.app")  # the Core's log: one name for all its parts

# a translator on this very device — the phone's Offline Translator app (dev.davidv.
# translator, through its AIDL API): fn(text, source, target) -> text, set by the phone's
# bridge; None anywhere else (feed.translate_backend = "device" then does nothing)
DEVICE: Any = None


class TranslateMixin(CoreState):
    """A part of Core (core/app.py): see the module's words."""

    def translate(self, status):
        """The post in the interface's language, by my server — or by LibreTranslate
        (feed.translate_backend) — a future of {content, detected_source_language,
        provider}."""
        from ..i18n import current_language
        if self._own_translator():
            st = real(status)
            return self.submit(lambda: self._translate_own(st, current_language()))
        return self.call_api("translate", real(status)["id"], current_language())

    def translate_html(self, html):
        """Any HTML (a profile's bio and fields) in the interface's language — a future
        of {content, detected_source_language, provider}. Only a translator of my own
        can (feed.translate_backend = "libretranslate"): a server translates its posts,
        by their id, and nothing else (Mastodon's /translate)."""
        from ..i18n import _, current_language
        def job():
            if not self._own_translator():
                raise ValueError(_("translate_profile_needs"))
            return self._translate_own({"content": html}, current_language())
        return self.submit(job)

    def _own_translator(self):
        """A translator other than my server's: LibreTranslate at translate_url, or the
        device's own (the phone's Offline Translator)."""
        feed = self.cfg["feed"]
        if feed.get("translate_backend") == "device":
            return DEVICE is not None
        return feed.get("translate_backend") == "libretranslate" and \
            str(feed.get("translate_url") or "").startswith(("https://", "http://"))

    def _on_device(self):
        return self.cfg["feed"].get("translate_backend") == "device" and DEVICE is not None

    def _translate_own(self, st, into):
        """The post (its HTML, its warning) by my own translator — the device's or
        LibreTranslate."""
        return self._device(st, into) if self._on_device() else self._libre(st, into)

    def _device(self, st, into):
        """The device's translator takes plain text: the post's paragraphs, translated in
        one go, come back as paragraphs (its links and markup are the original's)."""
        from ..model.text import html_to_text
        text = html_to_text(st.get("content") or "").strip()
        out = DEVICE(text, "", into) if text else ""
        paras = [p.strip() for p in str(out or "").split("\n\n") if p.strip()]
        content = "".join("<p>" + html_escape(p).replace("\n", "<br>") + "</p>"
                          for p in paras)
        spoiler = str(DEVICE(raw.warning(st), "", into) or "") if raw.warning(st) else ""
        return raw.translation(content, spoiler,
                               detected_source_language=st.get("language") or "",
                               provider="Offline Translator")

    def _libre(self, st, into):
        """LibreTranslate's /translate: the post's HTML (and its warning) into `into`."""
        feed = self.cfg["feed"]
        url = str(feed["translate_url"]).rstrip("/")
        if not url.endswith("/translate"):
            url += "/translate"
        if url.startswith("http://") and not remote.cleartext_ok(url):
            from ..i18n import _
            raise ValueError(_("translate_insecure"))

        def one(text, fmt):
            body = {"q": text, "source": "auto", "target": into, "format": fmt}
            if feed.get("translate_key"):
                body["api_key"] = feed["translate_key"]
            r = requests.post(url, json=body, timeout=(10, 60),
                              headers={"User-Agent": USER_AGENT})
            if r.status_code >= 400:
                try:
                    why = r.json().get("error") or r.reason
                except ValueError:
                    why = r.reason
                raise proto.ServerError(r.status_code, str(why)[:200])  # not the protocol's
            got = r.json()
            return str(got.get("translatedText") or ""), \
                str((got.get("detectedLanguage") or {}).get("language") or "")
        content, lang = one(st.get("content") or "", "html")
        spoiler = one(raw.warning(st), "text")[0] if raw.warning(st) else ""
        return raw.translation(content, spoiler,
                               detected_source_language=lang or st.get("language") or "",
                               provider="LibreTranslate")

    def auto_translation(self, st):
        """The post with its translation in place of its text, when feed.translate_auto
        wants it translated and it is done; None otherwise — then it is asked for (in
        the background, a few at a time) and the card is drawn anew when it comes."""
        if not self.cfg["feed"].get("translate_auto") or not isinstance(st, dict):
            return None
        inner = raw.boosted(st) if isinstance(raw.boosted(st), dict) else st
        if not self._wants_translation(inner):
            return None
        cache = self._translated
        done = cache.get(inner.get("id"))
        if done is None:
            self._ask_translation(inner)
            return None
        if not done:  # it failed: the post as it is
            return None
        from ..i18n import _
        mark = _("translated_auto", lang=done.get("detected_source_language") or "?")
        text = f"<p><small>🌐 {html_escape(mark)}</small></p>" + (done.get("content") or "")
        out = dict(inner, content=text, _fedtail_translated=True)
        out = raw.with_translation(out, dict(done, content=text))
        return raw.with_boosted(st, out) if inner is not st else out

    def _wants_translation(self, st):
        from ..i18n import current_language
        from . import langs
        lang = langs.base(st.get("language"))
        if not lang or not (st.get("content") or "").strip():
            return False
        if self._own_translator() and not self._on_device() and \
                st.get("visibility") not in ("public", "unlisted"):
            # by itself, no private post goes to a translator outside the server (the
            # server's own /translate refuses them too): such a one only on a click
            return False
        mine = {langs.base(current_language())} | {
            langs.base(x) for x in (self.cfg["post"].get("languages") or [])} | {
            langs.base(self.cfg["post"].get("language"))}
        return lang not in mine and (self._own_translator() or
                                     getattr(self.caps, "translation", False))

    AUTO_TRANSLATE_AT_ONCE = 4

    def _ask_translation(self, st):
        sid = st.get("id")
        asking = self._translating
        if not sid or sid in asking or len(asking) >= self.AUTO_TRANSLATE_AT_ONCE:
            return
        asking.add(sid)

        def job():
            from ..i18n import current_language
            try:
                got = self._translate_own(st, current_language()) if self._own_translator() else \
                    self.api.translate(sid, current_language())
            except Exception as e:  # noqa: BLE001 — not translated: the post as it is
                log.info("auto translation of %s: %s", sid, e)
                got = {}
            cache = self._translated
            cache[sid] = got if isinstance(got, dict) and got.get("content") else {}
            while len(cache) > 500:
                cache.popitem(last=False)
            asking.discard(sid)
            if cache[sid]:
                self._lane_cache.clear()
                self.emit("status_updated", st)
                self.emit("lanes_updated", {lane.name: [] for lane in self.lanes})
        self.bg.submit(job)

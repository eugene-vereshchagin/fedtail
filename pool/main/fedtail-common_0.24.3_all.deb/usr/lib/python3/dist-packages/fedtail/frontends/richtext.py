"""Server HTML → the safe rich-text subset fedtail shows (QLabel in the window, a
page in the web interface). No Qt here."""

import html
import re
from datetime import UTC, datetime
from html.parser import HTMLParser
from pathlib import Path

_INVISIBLE = re.compile(r'<span class="invisible">.*?</span>', re.S)
_ELLIPSIS = re.compile(r'<span class="ellipsis">(.*?)</span>', re.S)
_IMG = re.compile(r'<img[^>]*?alt="([^"]*)"[^>]*>|<img[^>]*>', re.S)
_SCRIPTY = re.compile(r"<(script|style|iframe)[^>]*>.*?</\1>", re.S | re.I)
_TAG = re.compile(r"(<[^>]*>)")
_LONG_WORD = re.compile(r"\S{28,}")
LINK_TEXT = 40   # feed.link_chars' default: a bare URL longer than this is shortened
ZWSP = "\u200b"  # an invisible place where Qt may wrap a line


def _short_url(text, most=LINK_TEXT):
    """A bare URL as its link text: without the scheme, cut at most characters (0 — the
    whole of it, feed.link_chars)."""
    t = re.sub(r"^https?://(www\.)?", "", text)
    return t if not most or len(t) <= most else t[:most - 1] + "…"


def _breakable(text):
    """Hashes, keys and the like have no spaces; let them wrap instead of
    running off the card."""
    return _LONG_WORD.sub(lambda m: ZWSP.join(m.group(0)[i:i + 20]
                                            for i in range(0, len(m.group(0)), 20)), text)


def _fit_text(h, link_chars=LINK_TEXT):
    """Shorten URLs shown as link text, make long words wrappable. Only text
    between tags is touched; hrefs stay whole."""
    out, in_link = [], False
    for part in _TAG.split(h):
        if part.startswith("<"):
            low = part[:3].lower()
            if low.startswith("<a ") or low == "<a>":
                in_link = True
            elif low.startswith("</a"):
                in_link = False
            out.append(part)
            continue
        text = html.unescape(part)
        if in_link and re.match(r"^\s*https?://", text):
            text = _short_url(text.strip(), link_chars)  # short enough now: keep it unbroken
        else:
            text = _breakable(text)
        out.append(esc(text).replace("&#x27;", "'"))
    return "".join(out)


# What a post may contain on screen. QLabel runs no scripts (it's not a browser), but
# whatever is not on these lists goes anyway: no forms, tables, headings, fonts,
# pictures from paths, and no links but to the web — a post must not be able to hold
# a link to fedtail's own actions (fedtail:delete/…) or to a local file; links that
# only go somewhere inside (a profile, a tag, a thread) stay.
ALLOWED_TAGS = {"p", "br", "a", "span", "b", "strong", "i", "em", "u", "s", "del",
                "code", "pre", "blockquote", "ul", "ol", "li", "small"}
VOID_TAGS = {"br"}
DROP_WITH_CONTENT = {"script", "style", "iframe", "object", "embed", "template", "noscript",
                     "svg", "math", "head", "title", "textarea", "select"}
AS_PARAGRAPH = {"h1", "h2", "h3", "h4", "h5", "h6", "div", "section", "article", "header",
                "footer", "aside", "table", "figure", "figcaption", "details", "summary"}
AS_BREAK = {"tr", "hr", "dt", "dd"}
AS_SPACE = {"td", "th"}
# Links to the outside a post may hold, and what fedtail hands to the desktop to open.
# Never file: (on Windows, file://host/share sends the login's NTLM hash to that host),
# smb:, data:, javascript: or anything else a desktop might act on.
OUTSIDE_SCHEMES = ("http://", "https://", "mailto:", "xmpp:", "gemini://", "magnet:")
# links.in_app's own: going somewhere inside is fine, doing things is not
INSIDE_ACTIONS = ("account", "tag", "resolve", "thread")
SAFE_SCHEMES = OUTSIDE_SCHEMES + tuple(f"fedtail:{a}/" for a in INSIDE_ACTIONS)
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")


def link_chars(cfg):
    """feed.link_chars: where a bare URL's text is cut (0 — never)."""
    return int((cfg.get("feed") or {}).get("link_chars", LINK_TEXT))


def openable(url):
    """True for an address fedtail may hand to the browser or the desktop: the web and
    the few link kinds a post may hold. Folders and files of our own go another way."""
    return isinstance(url, str) and not _CONTROL.search(url) and \
        url.strip().lower().startswith(OUTSIDE_SCHEMES)


def _mailto(href):
    """A mailto: link with only the subject and the body it may suggest: "attach=" (and
    the like: a mail client may take a file of mine with it) or headers of its own go."""
    from urllib.parse import parse_qsl, quote, urlencode
    to, _q, query = href.partition("?")
    keep = [(k, v) for k, v in parse_qsl(query, keep_blank_values=True)
            if k.lower() in ("subject", "body")]
    return to + ("?" + urlencode(keep, quote_via=quote) if keep else "")


def safe_href(href):
    """The href a post's link may keep — exactly as it will be written, entities already
    decoded — or None. fedtail:resolve/ may wrap only a web address; the other inside
    links take one path segment (an id, a tag), never a path into the API."""
    from urllib.parse import unquote
    href = (href or "").strip()
    if not href or _CONTROL.search(href):
        return None
    low = href.lower()
    if low.startswith("mailto:"):
        return _mailto(href)
    if low.startswith(OUTSIDE_SCHEMES):
        return href
    if not low.startswith("fedtail:"):
        return None
    action, sep, arg = href[len("fedtail:"):].partition("/")
    action = action.lower()
    if not sep or not arg or action not in INSIDE_ACTIONS:
        return None
    inner = unquote(arg)
    if action == "resolve":
        if not inner.lower().startswith(("http://", "https://")) or _CONTROL.search(inner):
            return None
    elif any(c in inner for c in "/\\?#") or _CONTROL.search(inner):
        return None
    return f"fedtail:{action}/{arg}"


def plain_tip(text):
    """A tooltip from someone else's words (alt text, a name, a link): Qt takes a
    tooltip with a tag in it for HTML and draws it (pictures from file paths too), so
    the text is escaped and the tooltip made rich on purpose."""
    if not text:
        return ""
    return "<qt>" + html.escape(text, quote=False).replace("\n", "<br>") + "</qt>"


class _Sanitizer(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in DROP_WITH_CONTENT:
            self.skip += 1
            return
        if self.skip:
            return
        if tag in AS_PARAGRAPH:  # a heading or a box: text of its own, the plain way
            self.out.append("<p>")
            return
        if tag in AS_BREAK:
            self.out.append("<br>")
            return
        if tag in AS_SPACE:
            self.out.append(" ")
            return
        if tag not in ALLOWED_TAGS:
            return
        if tag == "a":
            # the parser has decoded the entities already: checked as it is written
            href = safe_href(dict(attrs).get("href"))
            self.out.append(f'<a href="{esc(href)}">' if href else "<a>")
            return
        self.out.append(f"<{tag}>")

    def handle_startendtag(self, tag, attrs):
        if self.skip:
            return
        if tag in VOID_TAGS or tag in AS_BREAK:
            self.out.append("<br>")

    def handle_endtag(self, tag):
        if tag in DROP_WITH_CONTENT:
            self.skip = max(0, self.skip - 1)
            return
        if self.skip:
            return
        if tag in AS_PARAGRAPH:
            self.out.append("</p>")
        elif tag in ALLOWED_TAGS and tag not in VOID_TAGS:
            self.out.append(f"</{tag}>")

    def handle_data(self, data):
        if not self.skip:
            self.out.append(esc(data))

    def handle_entityref(self, name):
        if not self.skip:
            self.out.append(esc(html.unescape(f"&{name};")))

    def handle_charref(self, name):
        if not self.skip:
            self.out.append(esc(html.unescape(f"&#{name};")))


def sanitize(h):
    """Rebuild server HTML from the allowed tags only, attributes dropped but a
    web link's href; the blank lines at its start and end gone."""
    p = _Sanitizer()
    p.feed(h or "")
    p.close()
    return trim_blank("".join(p.out))


_BLANK = r"(?:\s|<br>|<p>(?:\s|<br>)*</p>)"
_LEAD = re.compile(rf"^{_BLANK}+")
_LEAD_IN_P = re.compile(r"^(<p>)(?:\s|<br>)+")
_TAIL = re.compile(rf"{_BLANK}+$")
_TAIL_IN_P = re.compile(r"(?:\s|<br>)+(</p>)$")


def trim_blank(h):
    """Empty paragraphs, line breaks and spaces (no-break ones too) at the start and the
    end of a post: gone. A WordPress article came with a screenful of nothing before
    its first words — its pictures were paragraphs of their own, empty once the
    pictures went to the gallery below."""
    while True:
        was = h
        h = _LEAD_IN_P.sub(r"\1", _LEAD.sub("", h))
        h = _TAIL_IN_P.sub(r"\1", _TAIL.sub("", h))
        if h == was:
            return h


def esc(s):
    return html.escape(s or "", quote=True)


_STRIKE = re.compile(r"(?<![~\w])~~(?=\S)([^~]+?)(?<=\S)~~(?![~\w])")
_RAW = {"a", "code", "pre"}


def strike_tildes(h):
    """~~text~~ typed in a client with no Markdown, on a server with none (Mastodon):
    struck out, as the writer meant. Not inside links or code; not across tags."""
    if "~~" not in h:
        return h
    out, raw = [], 0
    for part in _TAG.split(h):
        if part.startswith("<"):
            name = part[1:].lstrip("/").split(None, 1)[0].rstrip(">/").lower() if \
                len(part) > 2 else ""
            if name in _RAW and not part.endswith("/>"):
                raw = max(0, raw + (-1 if part.startswith("</") else 1))
            out.append(part)
        elif raw or "~~" not in part:
            out.append(part)
        else:
            out.append(_STRIKE.sub(r"<s>\1</s>", part))
    return "".join(out)


def clean(content, link_color=None, markup=False, link_chars=LINK_TEXT):
    """markup: ~~text~~ struck out too (feed.text_markup); link_chars: a bare URL's text
    cut at so many characters (feed.link_chars, 0 — whole)."""
    h = _SCRIPTY.sub("", content or "")
    h = _INVISIBLE.sub("", h)
    h = _ELLIPSIS.sub(r"\1…", h)
    h = _IMG.sub(lambda m: esc(m.group(1) or ""), h)  # custom emoji → :shortcode:
    h = sanitize(h)
    if markup:
        h = strike_tildes(h)
    h = _fit_text(h, link_chars)
    style = "text-decoration:none;" + (f"color:{link_color};" if link_color else "")
    return h.replace("<a ", f'<a style="{style}" ')


_BLOCK_TAG = re.compile(r"<(p|div|li|blockquote|pre|h[1-6])\b([^>]*)>", re.I)


def spaced(h, percent):
    """appearance.line_spacing for QLabel's rich text: line-height on every block of
    its own, in a block wrapping it all — Qt doesn't pass it down to the paragraphs
    inside (a <div> around <p>s gave a third of it). 100 (the font's own): as it was."""
    if not h or percent == 100:
        return h

    def put(m):
        attrs = m.group(2)
        style = re.search(r'style="([^"]*)"', attrs)
        if style:
            attrs = attrs.replace(style.group(0),
                                  f'style="line-height:{percent}%;{style.group(1)}"')
        else:
            attrs += f' style="line-height:{percent}%"'
        return f"<{m.group(1)}{attrs}>"
    return f'<div style="line-height:{percent}%">{_BLOCK_TAG.sub(put, h)}</div>'


_TAG_SPLIT = re.compile(r"(<[^>]+>)")
_SHORTCODE = re.compile(r":([A-Za-z0-9_]{2,}):")


def emojify(h, emojis, px, local):
    """:shortcode: in the text (never inside a tag) becomes the server's picture, when
    that picture is already on disk; local(url) -> path or None. Our own <img>, after
    sanitizing, pointing only at our own cache. Returns (html, urls still missing)."""
    table = {code: url for code, url in map(_emoji_pair, emojis or ()) if code and url}
    if not table or ":" not in h:
        return h, []
    missing = []

    def sub(m):
        url = table.get(m.group(1))
        path = local(url) if url else None
        if not path:
            if url:
                missing.append(url)
            return m.group(0)
        src = esc(Path(path).resolve().as_uri())
        return (f'<img src="{src}" width="{px}" height="{px}" align="middle" '
                f'title=":{esc(m.group(1))}:">')
    parts = _TAG_SPLIT.split(h)
    for i in range(0, len(parts), 2):
        parts[i] = _SHORTCODE.sub(sub, parts[i])
    return "".join(parts), missing


# Emoji, for feed.emoji = false. Pictographs drawn as emoji by default (U+1F000 and up,
# the BMP ones with Emoji_Presentation), any symbol asked to be one by U+FE0F, and the
# glue around them: joiners, skin tones, keycaps, tag sequences (subdivision flags).
# Symbols drawn as text by default (⚠ ❤ ✓ ↔ ❯ …) stay unless an FE0F follows: the app's
# own glyphs and plain typography are not emoji.
_EMOJI_BMP = ("⌚⌛⏩-⏬⏰⏳◽◾☔☕♈-♓"
              "♿⚓⚡⚪⚫⚽⚾⛄⛅⛎⛔⛪"
              "⛲⛳⛵⛺⛽✅✊✋✨❌❎"
              "❓-❕❗➕-➗➰➿⬛⬜⭐⭕")
_EMOJI = re.compile(
    "(?:[\U0001F000-\U0001FAFF" + _EMOJI_BMP + "]"
    "|[^\\s<>&;]️⃣?"          # a text symbol (or a keycap digit) made emoji
    "|[\U0001F3FB-\U0001F3FF‍️⃣\U000E0020-\U000E007F])+")
_ALONE_SHORTCODE = re.compile(r"(?:(?<=\s)|^):[A-Za-z0-9_]{2,}:(?=\s|$|[.,!?;)])")


def emoji_urls(emojis):
    """{shortcode: picture address} of a post's or a name's custom emoji — the still one
    where the server gives it (an animated one moves in no interface's text)."""
    return {e.shortcode: e.static_url or e.url for e in emojis or ()
            if e.shortcode and (e.static_url or e.url)}


def strip_emoji(h, emojis=()):
    """h (sanitized HTML) without emoji: Unicode ones, the server's :shortcodes: this
    post names, and a :shortcode: standing alone as a word (a remote server's emoji the
    post didn't list). Only text between tags is touched; spaces left doubled are one."""
    known = {code for code, _url in map(_emoji_pair, emojis or ()) if code}
    parts = _TAG_SPLIT.split(h)
    for i in range(0, len(parts), 2):
        t = _EMOJI.sub("", parts[i])
        if known:
            t = _SHORTCODE.sub(lambda m: "" if m.group(1) in known else m.group(0), t)
        t = _ALONE_SHORTCODE.sub("", t)
        parts[i] = re.sub(r"[  ]{2,}", " ", t)
    return "".join(parts)


def display_name(account):
    """The name to show, escaped (an Account)."""
    return esc(account.name or account.username or account.handle)


def _emoji_pair(e):
    """(shortcode, picture url) of a custom emoji (an Emoji)."""
    return e.shortcode, e.static_url or e.url


def when(iso, months):
    """'14 Oct 10:05' this year, '14 Oct 2024' before."""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone()
    except (ValueError, AttributeError):
        return ""
    now = datetime.now(UTC).astimezone()
    mon = months[dt.month - 1]
    if dt.year != now.year:
        return f"{dt.day} {mon} {dt.year}"
    return f"{dt.day} {mon} {dt:%H:%M}"


def link(action, arg, label, color=None, bold=False):
    """An in-app link. QLabel ignores stylesheets for links, so style goes inline."""
    style = "text-decoration:none;"
    if color:
        style += f"color:{color};"
    if bold:
        style += "font-weight:700;"
    return f'<a href="fedtail:{action}/{esc(str(arg))}" style="{style}">{label}</a>'


def history_html(versions, date, link_color=None):
    """An edited post's versions (Posts, oldest first) for the history dialog. The
    warning is the author's plain text like the rest: escaped, never markup."""
    from ..i18n import _
    parts = []
    for i, v in enumerate(versions or (), 1):
        cw = f"<p><i>⚠ {esc(v.warning)}</i></p>" if v.warning else ""
        when = date(v.created) if v.created else ""
        parts.append(f"<h4>{_('history_version', n=i)} · {esc(when)}"
                     f"</h4>{cw}{clean(v.text, link_color)}")
    return "<hr>".join(parts)

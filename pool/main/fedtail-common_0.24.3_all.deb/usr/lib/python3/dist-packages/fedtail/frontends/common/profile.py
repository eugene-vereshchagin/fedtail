"""What a profile offers — the line about the person and the buttons under it — and
what each button does, once for every interface: all of them take both from here, so
they say and offer the same.

`actions()` says which buttons, in which order, with which words, from who they are to
me (Relationship) and what my server can do. `do()` carries one out through a `host`
(the window):

  call(future, ok=None, fail=None)   in the GUI thread when done
  confirm(title, text, then)         ask first; then() on yes
  ask_text(title, question, then, text="")   a line to type; then(text)
  compose(text=...)  open_people(acc, which)  copy_handle(handle)  open_url(url)
  edit_profile()  open_lists(acc)
  status(text)  error(text)

and `changed(rel)` gets the relationship as it is afterwards (the server's answer, or
the old one with the change made when the server says nothing)."""

from __future__ import annotations

from dataclasses import dataclass, replace

from ...i18n import _
from ...model import Relationship
from ...model.text import note_text
from . import timed


@dataclass(frozen=True)
class Act:
    key: str            # what do() is asked to do
    label: str
    tip: str = ""
    primary: bool = False


def meta(acc, rel, date, followed_since=None, software=""):
    """The line under the name: @handle, a bot, locked, since when, follows me, how
    long I follow them, the server's software. Plain text pieces."""
    bits = ["@" + acc.handle]
    if acc.bot:
        bits.append(_("bot"))
    if acc.locked:
        bits.append("🔒 " + _("acc_locked"))
    if acc.created:
        bits.append(_("acc_since", date=acc.created.strftime("%d.%m.%Y")))
    if rel is not None and rel.followed_by:
        bits.append(_("acc_follows_you"))
    if software:
        bits.append("🖥 " + software)
    if followed_since:
        bits.append(_("acc_followed_since", when=date(followed_since)))
    return bits


def actions(acc, rel, mine, cfg, supports, lists=False, details=False, collections=False):
    """The profile's buttons, in order. details: "Profile…" — the head's details as a
    place of its own (the web page and the terminal: the windows show them in the tab);
    collections: "Add to collection…" and "Collections" (Mastodon 4.6), places all the
    interfaces draw — the windows in a place window (qt/place.py, gtk/place.py)."""
    rel = rel or Relationship()
    out = []
    if mine:
        out.append(Act("edit_profile", _("edit_profile")))
    if not mine:
        following = rel.following
        out.append(Act("follow", _("unfollow") if following else
                       (_("follow_requested") if rel.requested else _("follow")),
                       primary=not following))
        if following or rel.requested:
            # a follow waiting for the other server's yes (GoToSocial says "requested" till
            # then, unlocked accounts too) takes the bell already: it holds with the follow
            out.append(Act("bell", "🔔 " + (_("bell_off") if rel.notifying else _("bell_on")),
                           _("bell_tip")))
        if following:
            if cfg["feed"].get("per_person_follow", True):
                out.append(Act("boosts", "♻ " + (_("boosts_hide") if rel.showing_shares
                                                 else _("boosts_show")),
                               _("boosts_person_tip")))
                langs = list(rel.languages or ())
                out.append(Act("langs", "🌐 " + (", ".join(langs) if langs else _("langs_all")),
                               _("langs_person_tip")))
        if following and cfg["feed"].get("home_hide"):
            hidden = rel.hidden_home
            out.append(Act("home_hide", "🏠 " + (_("home_hide_off") if hidden
                                                 else _("home_hide_on")), _("home_hide_tip")))
        if cfg["feed"].get("watch_replies"):  # rare: who answers someone (a bot of mine)
            out.append(Act("watch_replies", _("watch_replies_off") if rel.watched_replies
                           else _("watch_replies_on"), _("watch_replies_tip")))
        out.append(Act("mention", _("mention")))
        out.append(Act("mute", _("unmute") if rel.muting else _("mute")))
        out.append(Act("block", _("unblock") if rel.blocking else _("block")))
        if rel.followed_by and supports("remove_follower"):
            out.append(Act("remove_follower", _("remove_follower")))
        if following and supports("endorse"):
            out.append(Act("endorse", _("unendorse") if rel.endorsed else _("endorse"),
                           _("endorse_tip")))
        if lists and (cfg.get("lists") or {}).get("enabled", True):  # lists.enabled
            out.append(Act("lists", _("add_to_list")))
        if collections and supports("collections"):
            out.append(Act("collect", _("collect"), _("collect_tip")))
    for which, n in (("following", acc.following), ("followers", acc.followers)):
        if n:
            out.append(Act(which, _(f"people_{which}_n", n=n)))
    if not mine:
        out.append(Act("note", _("note_edit"), _("note_tip")))
        if cfg["feed"].get("aliases"):  # my own name for them, here only
            out.append(Act("alias", "✎ " + _("alias_edit"), _("alias_tip")))
        if cfg["feed"].get("nick_colors"):  # their name in my colour, here only
            out.append(Act("nick_color", "🎨 " + _("color_edit"), _("color_tip")))
    if not mine and cfg["feed"].get("translate", True) and \
            ((getattr(acc, "note", "") or "").strip() or getattr(acc, "fields", ())):
        out.append(Act("translate", "🌐 " + _("translate"), _("translate_profile_tip")))
    out.append(Act("copy_handle", _("copy_handle"), _("copy_handle_tip")))
    if acc.url:
        out.append(Act("open_browser", _("open_browser")))
    if collections and supports("collections"):
        out.append(Act("collections", _("collections_mine") if mine else _("collections")))
    if details:
        out.append(Act("details", "ℹ " + _("profile_title") + "…"))
    return out


def day(when):
    """A day in words for meta(): an aware datetime (the model's) or ISO text — the date
    I follow someone since is text (core.followed_since). For an interface with no
    theme's date of its own (the page, the terminal)."""
    from datetime import datetime
    if not when:
        return ""
    if isinstance(when, str):
        try:
            when = datetime.fromisoformat(when.replace("Z", "+00:00"))
        except ValueError:
            return when[:10]
        if when.tzinfo is None:
            return when.strftime("%d.%m.%Y")
    return when.astimezone().strftime("%d.%m.%Y")


def home_of(acc):
    """The server a person lives on (for "what it runs", core.server_software), or ""."""
    from urllib.parse import urlparse
    return urlparse(acc.url or acc.uri or "").hostname or ""


def origin_host(acc, cfg):
    """The server whose own list of their posts goes further back than mine
    (feed.remote_profiles): a person of another server — else ""."""
    handle = acc.handle if acc else ""
    if "@" not in handle or not (cfg.get("feed") or {}).get("remote_profiles", True):
        return ""
    return handle.split("@", 1)[1]


FAMILIAR_SHOWN = 5


def familiar_line(known):
    """"Followed by @a, @b and 3 more" — whom of mine follows them too; "" for none."""
    known = [a for a in known or () if a.id]
    if not known:
        return ""
    more = len(known) - FAMILIAR_SHOWN
    return _("familiar", who=", ".join("@" + a.handle for a in known[:FAMILIAR_SHOWN]) +
             (" " + _("act_more", n=more) if more > 0 else ""))


def featured_lines(feat):
    """What they put forward (feed.profile_featured), in words: [(title, text, tags,
    people)] — their featured tags with how many posts, the people they recommend."""
    feat = feat or {}
    out = []
    tags = [t for t in feat.get("tags") or [] if t.name]
    people = [a for a in feat.get("people") or [] if a.id]
    if tags:
        out.append((_("featured_tags"),
                    ", ".join("#" + t.name + (f" ({int(t.posts)})" if t.posts else "")
                              for t in tags), tags, []))
    if people:
        out.append((_("featured_people"), ", ".join("@" + a.handle for a in people),
                    [], people))
    return out


def moved_line(acc, cfg):
    """"This account moved to @new" as plain words (feed.show_moved), or ""."""
    import re
    from html import unescape
    if not getattr(acc, "moved", None) or not (cfg.get("feed") or {}).get("show_moved", True):
        return ""
    return unescape(re.sub(r"<[^>]+>", "", _("moved_to", acct="@" + acc.moved.handle)))


def note_line(rel, mine):
    """My private note on them, to show under the buttons ("" if none)."""
    note = note_text(rel.note if rel is not None else "").strip()
    return "" if mine or not note else "📝 " + note


def parse_langs(text):
    return [x.strip().lower() for x in (text or "").replace(";", ",").replace(" ", ",")
            .split(",") if x.strip()]


def do(key, acc, rel, view, host, changed):
    """Carry out a profile button (key from actions())."""
    rel = rel or Relationship()

    def after(**now):
        return lambda r: changed(r if isinstance(r, Relationship) else replace(rel, **now))
    if key == "follow":
        on = not (rel.following or rel.requested)
        host.call(view.follow(acc.id, on), changed)
    elif key == "bell":
        on = not rel.notifying
        host.call(view.notify_posts(acc.id, on), after(notifying=on), host.error)
    elif key == "boosts":
        on = not rel.showing_shares
        host.call(view.follow_options(acc.id, reblogs=on), after(showing_shares=on),
                  host.error)
    elif key == "langs":
        def set_langs(text):
            langs = parse_langs(text)
            host.call(view.follow_options(acc.id, languages=langs),
                      after(languages=tuple(langs) or None), host.error)
        host.ask_text(_("langs_person_title", acct=acc.handle), _("langs_person_ask"),
                      set_langs, ", ".join(rel.languages or ()), allow_empty=True)
    elif key == "home_hide":  # out of Home, still followed (feed.home_hide)
        on = not rel.hidden_home
        host.call(view.hide_from_home(acc.id, on), after(hidden_home=on), host.error)
    elif key == "watch_replies":  # every post's replies followed (people.watch_replies)
        on = not rel.watched_replies
        host.call(view.watch_replies(acc.id, on), after(watched_replies=on), host.error)
    elif key == "mention":
        host.compose(text=f"@{acc.handle} ")
    elif key == "mute":
        if rel.muting:
            host.call(view.mute(acc.id, False), after(muting=False))
        else:  # how long, and their notifications too or not
            timed.mute(view, host, acc, after(muting=True))
    elif key == "block":
        on = not rel.blocking

        def go():
            host.call(view.block(acc.id, on), after(blocking=on))
        if on:
            host.confirm(_("block"), _("block_q", acct=acc.handle), go)
        else:
            go()
    elif key == "remove_follower":
        def go():
            done = after(followed_by=False)
            host.call(view.remove_follower(acc.id),
                      lambda r: (done(r), host.status(_("follower_removed",
                                                         acct=acc.handle))), host.error)
        host.confirm(_("remove_follower"), _("remove_follower_q", acct=acc.handle), go)
    elif key == "endorse":
        on = not rel.endorsed
        host.call(view.endorse(acc.id, on), after(endorsed=on), host.error)
    elif key in ("following", "followers"):
        host.open_people(acc, key)
    elif key == "note":
        old = rel.note
        host.ask_text(_("note_title", acct=acc.handle), _("note_tip"),
                      lambda text: host.call(view.set_note(acc.id, text.strip(), old),
                                             after(note=text.strip()), host.error),
                      note_text(old), allow_empty=True)
    elif key == "alias":  # my own name for them (feed.aliases): "" — theirs again
        host.ask_text(_("alias_title", acct=acc.handle), _("alias_tip"),
                      lambda text: host.call(view.set_alias(acc.id, text.strip()),
                                             lambda _r: host.status(_("alias_saved")),
                                             host.error),
                      acc.name, allow_empty=True)
    elif key == "nick_color":  # people.nick_colors: a colour's name or #rrggbb; "" — none
        host.ask_text(_("color_title", acct=acc.handle), _("color_tip"),
                      lambda text: host.call(view.set_nick_color(acc.id, text.strip()),
                                             lambda _r: host.status(_("color_saved")),
                                             host.error),
                      acc.color, allow_empty=True)
    elif key == "edit_profile":
        host.edit_profile()
    elif key == "lists":  # "Add to list": which lists they're in, a tick each
        host.open_lists(acc)
    elif key == "copy_handle":
        host.copy_handle(acc.handle)
    elif key == "open_browser":
        host.open_url(acc.url)
    elif key == "details":  # the place of the profile's details (common/placesmore.py)
        host._place("profile_info", acc.id)
    elif key == "collections":  # theirs, or mine (common/places.py)
        host._place("collections", "" if view.me and acc.id == view.me.id else acc.id)
    elif key == "translate":  # the bio and fields in my language (places: profile_translate)
        host._place("profile_translate", acc.id)
    elif key == "collect":  # "Add to collection": mine, a tick where they are
        host._place("collect", acc.id)

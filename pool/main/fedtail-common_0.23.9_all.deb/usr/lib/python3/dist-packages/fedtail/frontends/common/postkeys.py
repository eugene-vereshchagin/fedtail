"""The keys of a lane's posts (ui.post_keys, help/keys.md "A lane and a thread"): j / k
walk the posts, r f b m o and Enter act on the one under the cursor, as a fedtail: link
of its card would. One table for every window: GTK had none of them (21.11)."""

# a key's name (lower case; Enter by its name) -> the card's link action
ACTIONS = {"r": "reply", "f": "fav", "b": "boost", "m": "bookmark", "o": "thread",
           "enter": "thread", "return": "thread", "kp_enter": "thread"}
WALK = {"j": 1, "k": -1}


def step(posts, at, delta, first_on_screen=None):
    """The post the cursor goes to: from `at` by delta (stopping at either end), or —
    no cursor among the posts yet — the first one on screen."""
    if not posts:
        return None
    if at not in posts:
        return first_on_screen if first_on_screen in posts else posts[0]
    return posts[max(0, min(len(posts) - 1, posts.index(at) + delta))]


def link(action, post_id):
    """What the card's own link for it says: fedtail:<action>/<id> (common/links.py)."""
    return f"fedtail:{action}/{post_id}"


# a thread's own keys (help/keys.md): ] / [ the next / previous top comment, - its branch
THREAD_KEYS = {"bracketright": 1, "bracketleft": -1}
FOLD = "minus"


def top_comment(posts, at, delta, depth_of):
    """] / [ in a thread: the next (delta > 0) or previous comment at the top of the tree
    (depth 1, the post itself 0) from `at`; None when there is no other. One rule for
    Qt, GTK, the terminal and the page (the terminal skipped the post itself)."""
    tops = [k for k in posts if depth_of(k) <= 1]
    if len(tops) < 2:
        return None
    i = posts.index(at) if at in posts else -1
    if delta > 0:
        return next((k for k in tops if posts.index(k) > i), tops[-1])
    return next((k for k in reversed(tops) if posts.index(k) < i), tops[0])


def branch(every, at, depth_of):
    """- in a thread: (head, below) — the branch the key folds: from however deep a reply
    it is pressed, its top comment's; below: the keys under the head, deeper than it.
    every: all the thread's keys in order (folded ones too)."""
    i = every.index(at)
    depth = depth_of(at)
    if depth > 1:
        i = next((j for j in range(i, -1, -1) if depth_of(every[j]) <= 1), i)
        depth = depth_of(every[i])
    below = []
    for k in every[i + 1:]:
        if depth_of(k) <= depth:
            break
        below.append(k)
    return every[i], below


def fold(folded, hidden, head, below):
    """The branch under head folded away, or shown again: folded (heads) and hidden (the
    keys not drawn) changed in place. → whether anything changed."""
    if not below:
        return False
    if head in folded:
        folded.discard(head)
        hidden.difference_update(below)
    else:
        folded.add(head)
        hidden.update(below)
    return True

"""What a protocol gives the core (docs/en/dev/protocols.md, stage 3).

A protocol is a package under ``fedtail/protocols/`` that exposes a ``PROTOCOL``:

* ``client`` — the class the core talks to the server through: ``client(server)`` before
  login, ``client(server, token)`` after; its methods are the ones in ``CLIENT``, named
  as the core calls them. A new protocol implements these (those it can't, raise
  ``NotSupported`` and the core hides the feature).
* ``error`` — the exception its client raises for an answer that is an error; it has a
  ``status`` (HTTP or alike: 404, 405, 410, 501 mean "no such thing here").
* ``capabilities(instance)`` — what the server says about itself → ``Capabilities``.
* ``adapter`` — the server's objects → ``fedtail.model`` (``post``, ``account``, …).
* ``stream`` — a live stream class, or None.
* ``address``, ``tune``, ``probe``, ``counters``, ``urls`` — the server's address from
  what a person typed, the client's settings, "what can it do", the honest counters
  from a post's own server, and the addresses of other servers' public pages: the core
  reaches the protocol through these, never into its modules (core/proto.py).

The core still keeps a server's raw objects in its store and reads some of their fields
(that is the Mastodon dialect every server of today speaks); what reaches the frontends
is the model only (core/view.py). ``tests/test_protocols.py`` keeps the API itself
inside ``protocols/``: no ``/api/v…`` path in the code anywhere else, and the core calls
only methods listed here.
"""

import mimetypes
import time
from dataclasses import dataclass, field
from typing import Any


class ServerError(Exception):
    """A server's answer that is an error, whatever the protocol: status as in HTTP
    (404, 405, 410, 501 — no such thing here; 401, 403 — not for me)."""

    def __init__(self, status, message):
        super().__init__(f"HTTP {status}: {message}")
        self.status = status


class RateLimited(ServerError):
    """The server asks to wait: too many requests (HTTP 429), until `until` (a unix time).
    Also raised without asking it, while its budget is spent (the client knows)."""

    def __init__(self, message, until):
        super().__init__(429, message)
        self.until = until


@dataclass
class Budget:
    """What the server allows: requests per window, how many are left, when it starts
    anew (unix time); as its last answer said. limit 0: it doesn't say."""
    limit: int = 0
    remaining: int = 0
    reset: float = 0.0

    def spent(self, now=None):
        """Nothing left and the window still on: asking now only earns a 429."""
        now = time.time() if now is None else now
        return bool(self.limit) and self.remaining <= 0 and now < self.reset

    def low(self, reserve, now=None):
        """Fewer left than reserve (a poll round's worth and some), the window on."""
        now = time.time() if now is None else now
        return bool(self.limit) and self.remaining < reserve and now < self.reset

# every method of the client the core calls (self.api.<name>, api.<name>); and its
# attribute ``base``, the server's address
CLIENT = frozenset("""
    account account_statuses announcements react_status answer_interaction
    answer_notification_request
    async_refresh authorize_follow authorize_url block block_domain blocks bookmark
    bookmarks cancel_scheduled clear_notifications context conversations create_filter
    collections_of in_collections collection create_collection update_collection
    delete_collection collection_add collection_remove collection_revoke
    create_list custom_emojis delete_filter delete_list delete_status directory
    filter_status filter_statuses unfilter_status update_filter update_media link_timeline
    featured_tag_suggestions instance_domain_blocks terms_of_service translation_languages
    push_subscription push_subscribe push_unsubscribe
    dismiss_announcement dismiss_notification dismiss_notification_group
    dismiss_suggestion domain_blocks
    edit_status endorse endorsements familiar_followers favourite favourited_by
    favourites feature_tag featured_tags federated filters follow follow_options
    follow_requests follow_tag followed_tags followers following get_token home
    instance instance_page instance_rules interaction_requests list_accounts list_add
    list_remove list_timeline lists local markers me mentions mute mute_conversation
    mutes my_featured_tags notification_groups notification_policy notification_requests
    notifications
    notify_posts pin pinned poll post_status preferences quotes react_announcement
    read_conversation reblog reblogged_by register_app reject_follow relationship
    relationships remove_from_followers report revoke_quote scheduled search search_statuses
    set_markers set_note set_notification_policy status status_history status_source suggestions
    instance_v2 tag tag_timeline translate trends unfeature_tag update_credentials update_list
    upload_media verify_credentials vote base
""".split())


# what is known of a server without asking it: (software, feature) -> there or not
# features only some software has: offered there alone (not "yes until it says no")
OPT_IN = {
    # emoji reactions to posts: Pleroma's and Akkoma's API, Fedibird's (the Misskey kin
    # that speak Mastodon's API take that one)
    "reactions": {"akkoma", "pleroma", "misskey", "sharkey", "firefish", "iceshrimp",
                  "catodon", "foundkey", "cherrypick", "fedibird"},
}

KNOWN = {
    # Mastodon 4.6's collections: the others answer 404 (the menu item went only after
    # a first try said so — the self-check of 26.10 on GoToSocial)
    ("gotosocial", "collections"): False, ("akkoma", "collections"): False,
    ("pleroma", "collections"): False, ("misskey", "collections"): False,
    ("sharkey", "collections"): False, ("iceshrimp", "collections"): False,
    ("firefish", "collections"): False,
    ("gotosocial", "dismiss_one"): False,   # it clears all notifications, never one
    ("gotosocial", "grouped"): False,       # no /api/v2/notifications (asking: a 404)
    ("gotosocial", "domain_blocks"): False,  # a user's own server blocks: admins only
}


@dataclass
class Capabilities:
    """What my server can do — one place for it (docs/en/dev/protocols.md, stage 4).

    What the server says about itself (software, version, the limits) comes with the
    connection; whether it has a feature is learned: a probe's answers (≡ → Server info
    → What it can do), an answer "no such thing here" to a call (Core._api), and what is
    known of its software (KNOWN). has(feature) is True until one of them says no — a
    button is offered, and goes once the server refuses it.

    Feature names are short words the core uses: "conversations", "dismiss",
    "dismiss_one", "mute_thread", "trends_tags", "quotes"…"""
    software: str = ""
    version: str = ""  # what the server says it runs ("4.3.0", "0.17.3 git-…")
    software_sure: bool = False  # False: software is a guess (the core asks nodeinfo)
    max_characters: int = 500
    max_media: int = 4
    markdown: bool = False
    max_poll_options: int = 4
    max_profile_fields: int = 4  # GoToSocial and Akkoma say theirs; Mastodon keeps 4
    translation: bool = False
    streaming: str = ""  # wss://… of the live stream, "" — not said
    image_bytes: int = 0   # the largest picture the server takes, bytes (0 — not said)
    image_pixels: int = 0  # …and in pixels, width × height
    media_types: list = field(default_factory=list)  # the attachments' MIME types it
    # takes ("image/png", "video/*"…), [] — not said
    missing: set = field(default_factory=set)  # the server said no
    present: set = field(default_factory=set)  # the server said yes (a probe)

    def has(self, feature):
        if feature in self.missing:
            return False
        if feature in self.present:
            return True
        if feature in OPT_IN:
            return (self.software or "").lower() in OPT_IN[feature]
        return KNOWN.get(((self.software or "").lower(), feature), True)

    def learn(self, feature, there):
        """The server answered for a feature. True: that changed what has() says."""
        before = self.has(feature)
        (self.present if there else self.missing).add(feature)
        (self.missing if there else self.present).discard(feature)
        return self.has(feature) != before

    def same_server(self, software, version):
        return (software or "") == self.software and (version or "") == self.version


@dataclass(frozen=True)
class Protocol:
    name: str
    client: type
    error: type
    capabilities: Any   # (instance dict) -> Capabilities
    adapter: Any        # module: the server's objects -> fedtail.model
    stream: Any = None  # module with the live stream, or None
    # what the core used to reach around the protocol for (protocols.md, stage 3):
    address: Any = None   # (what a person typed: "social.example", @me@host) -> its URL
    tune: Any = None      # (slow_seconds=…) -> None: the client's own settings
    probe: Any = None     # module: run(client, caps), features(result), KV
    counters: Any = None  # module: origin_api_url(status, own), merge(status, origin)
    urls: Any = None      # the addresses of other servers' public pages: search, lookup,
    #                       statuses, public, tag (fetched without a token, core/remote)


# Types the system may not know (Python on Windows asks the registry: .md, .fb2, .epub
# often aren't there and go as application/octet-stream) — ours first, the same on every
# system; then the system's.
MEDIA_TYPES = {
    ".md": "text/markdown", ".markdown": "text/markdown", ".txt": "text/plain",
    ".pdf": "application/pdf", ".epub": "application/epub+zip",
    ".fb2": "application/x-fictionbook+xml", ".djvu": "image/vnd.djvu",
    ".odt": "application/vnd.oasis.opendocument.text",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif",
    ".webp": "image/webp", ".avif": "image/avif", ".heic": "image/heic",
    ".heif": "image/heif", ".jxl": "image/jxl", ".svg": "image/svg+xml",
    ".mp4": "video/mp4", ".m4v": "video/mp4", ".webm": "video/webm",
    ".mov": "video/quicktime", ".mkv": "video/x-matroska",
    ".mp3": "audio/mpeg", ".ogg": "audio/ogg", ".oga": "audio/ogg", ".opus": "audio/ogg",
    ".m4a": "audio/mp4", ".flac": "audio/flac", ".wav": "audio/wav",
}


def media_type(path):
    """An attachment's MIME type by its name, or "" — not known."""
    import os
    ext = os.path.splitext(str(path))[1].lower()
    return MEDIA_TYPES.get(ext) or mimetypes.guess_type(str(path))[0] or ""


def media_taken(path, types):
    """Whether a server that takes `types` (Capabilities.media_types) takes this file:
    True when it doesn't say, or the file's type isn't known here (the server decides)."""
    kind = media_type(path)
    if not types or not kind:
        return True
    types = {str(t).lower() for t in types}
    return kind in types or kind.split("/")[0] + "/*" in types
